const { validateLicense, getMachineId } = require("./index");

/**
 * License check middleware — called once on startup
 * Returns { valid, machineId, message }
 */
function checkLicense() {
  const key = process.env.LICENSE_KEY || "";
  const machineId = getMachineId();

  if (!key) {
    return {
      valid: false,
      machineId,
      message: "No license key found. Set LICENSE_KEY in your .env file.",
    };
  }

  const valid = validateLicense(key);
  return {
    valid,
    machineId,
    message: valid
      ? "License valid."
      : "Invalid license key. This software is not licensed for this machine.",
  };
}

module.exports = { checkLicense };
