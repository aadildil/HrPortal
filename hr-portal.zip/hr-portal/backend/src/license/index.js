const crypto = require("crypto");
const os = require("os");

// Secret salt — only you know this. Change this to something private.
const SECRET = "SAFEWAY_HR_2025_X9K2M";

/**
 * Get a stable machine fingerprint from physical MAC addresses only
 * Filters out virtual interfaces (Docker, VPN, loopback etc.)
 */
function getMachineId() {
  const nets = os.networkInterfaces();
  const macs = [];

  // Keywords that indicate virtual/non-physical interfaces
  const virtualKeywords = [
    "docker", "veth", "br-", "virbr", "vmware", "vbox",
    "utun", "tun", "tap", "vpn", "lo", "loopback", "pseudo"
  ];

  for (const name of Object.keys(nets)) {
    const nameLower = name.toLowerCase();
    const isVirtual = virtualKeywords.some(k => nameLower.includes(k));
    if (isVirtual) continue;

    for (const net of nets[name]) {
      if (
        !net.internal &&
        net.mac &&
        net.mac !== "00:00:00:00:00:00" &&
        net.family === "IPv4"
      ) {
        macs.push(net.mac);
      }
    }
  }

  // Sort for consistency regardless of interface order
  macs.sort();

  // Fallback: if no physical MACs found, use hostname
  if (macs.length === 0) {
    return os.hostname();
  }

  // Use only the first MAC for maximum stability
  return macs[0];
}

/**
 * Generate a license key for a given machine ID
 */
function generateKey(machineId) {
  const hash = crypto
    .createHmac("sha256", SECRET)
    .update(machineId)
    .digest("hex")
    .toUpperCase()
    .slice(0, 32);
  return hash.match(/.{4}/g).join("-");
}

/**
 * Validate the license key against this machine
 */
function validateLicense(key) {
  if (!key) return false;
  const machineId = getMachineId();
  const expectedKey = generateKey(machineId);
  return key.replace(/\s/g, "") === expectedKey.replace(/\s/g, "");
}

module.exports = { getMachineId, generateKey, validateLicense };
