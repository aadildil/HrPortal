const { pool } = require("../db");
const fs = require("fs");
const path = require("path");

const ok = (res, data, status = 200) =>
  res.status(status).json({ success: true, data });
const err = (res, message, status = 500) =>
  res.status(status).json({ success: false, message });

// GET /documents?entityType=company&entityId=1
exports.getDocuments = async (req, res) => {
  try {
    const { entityType, entityId } = req.query;
    if (!entityType || !entityId) return err(res, "entityType and entityId required", 400);
    const rows = await pool.query(
      `SELECT * FROM documents WHERE entity_type=$1 AND entity_id=$2 ORDER BY uploaded_at DESC`,
      [entityType, entityId]
    );
    ok(res, rows.rows);
  } catch (e) {
    err(res, e.message);
  }
};

// POST /documents  (single file)
exports.uploadDocument = async (req, res) => {
  try {
    const { entityType, entityId, documentName, documentType, expiryDate } = req.body;
    if (!entityType || !entityId) return err(res, "entityType and entityId required", 400);
    if (!req.file) return err(res, "File is required", 400);

    const row = await pool.query(
      `INSERT INTO documents (entity_type, entity_id, document_name, document_type, file_path, file_original_name, expiry_date)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [entityType, entityId, documentName || req.file.originalname, documentType, req.file.path, req.file.originalname, expiryDate || null]
    );
    ok(res, row.rows[0], 201);
  } catch (e) {
    err(res, e.message);
  }
};

// POST /documents/bulk  (multiple files with individual metadata)
exports.uploadDocumentsBulk = async (req, res) => {
  try {
    const { entityType, entityId } = req.body;
    if (!entityType || !entityId) return err(res, "entityType and entityId required", 400);
    if (!req.files || req.files.length === 0) return err(res, "No files uploaded", 400);

    // metadata is a JSON array: [{documentName, documentType, expiryDate}, ...]
    let metadata = [];
    try {
      metadata = JSON.parse(req.body.metadata || "[]");
    } catch {
      metadata = [];
    }

    const inserted = [];
    for (let i = 0; i < req.files.length; i++) {
      const file = req.files[i];
      const meta = metadata[i] || {};
      const row = await pool.query(
        `INSERT INTO documents (entity_type, entity_id, document_name, document_type, file_path, file_original_name, expiry_date)
         VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
        [
          entityType, entityId,
          meta.documentName || file.originalname,
          meta.documentType || "Other",
          file.path,
          file.originalname,
          meta.expiryDate || null
        ]
      );
      inserted.push(row.rows[0]);
    }

    ok(res, inserted, 201);
  } catch (e) {
    err(res, e.message);
  }
};

// GET /documents/:id/download
exports.downloadDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const row = await pool.query("SELECT * FROM documents WHERE id=$1", [id]);
    if (!row.rows.length) return err(res, "Document not found", 404);
    const doc = row.rows[0];
    if (!fs.existsSync(doc.file_path)) return err(res, "File not found on disk", 404);
    res.download(doc.file_path, doc.file_original_name || path.basename(doc.file_path));
  } catch (e) {
    err(res, e.message);
  }
};

// GET /documents/:id/preview
exports.previewDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const row = await pool.query("SELECT * FROM documents WHERE id=$1", [id]);
    if (!row.rows.length) return err(res, "Document not found", 404);
    const doc = row.rows[0];
    if (!fs.existsSync(doc.file_path)) return err(res, "File not found on disk", 404);

    const ext = path.extname(doc.file_original_name || doc.file_path).toLowerCase();
    const mimeTypes = {
      ".pdf": "application/pdf",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".gif": "image/gif",
      ".webp": "image/webp",
    };

    const mimeType = mimeTypes[ext];
    if (!mimeType) {
      // For non-previewable files (doc, xlsx etc.) fall back to download
      return res.download(doc.file_path, doc.file_original_name || path.basename(doc.file_path));
    }

    res.setHeader("Content-Type", mimeType);
    res.setHeader("Content-Disposition", `inline; filename="${doc.file_original_name || path.basename(doc.file_path)}"`);
    fs.createReadStream(doc.file_path).pipe(res);
  } catch (e) {
    err(res, e.message);
  }
};

// DELETE /documents/:id
exports.deleteDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const row = await pool.query("SELECT * FROM documents WHERE id=$1", [id]);
    if (!row.rows.length) return err(res, "Document not found", 404);
    const doc = row.rows[0];
    if (fs.existsSync(doc.file_path)) fs.unlinkSync(doc.file_path);
    await pool.query("DELETE FROM documents WHERE id=$1", [id]);
    ok(res, { message: "Deleted" });
  } catch (e) {
    err(res, e.message);
  }
};

// GET /documents/expiring-csv
exports.exportExpiringCSV = async (req, res) => {
  try {
    const rows = await pool.query(`
      SELECT
        d.document_name, d.document_type, d.expiry_date, d.entity_type, d.entity_id,
        CASE WHEN d.entity_type='company' THEN c.name WHEN d.entity_type='employee' THEN e.name END AS owner_name,
        CASE WHEN d.entity_type='employee' THEN co.name ELSE NULL END AS company_name
      FROM documents d
      LEFT JOIN companies c ON d.entity_type='company' AND d.entity_id=c.id
      LEFT JOIN employees e ON d.entity_type='employee' AND d.entity_id=e.id
      LEFT JOIN companies co ON e.company_id=co.id
      WHERE d.expiry_date IS NOT NULL
        AND d.expiry_date >= CURRENT_DATE
        AND d.expiry_date <= CURRENT_DATE + INTERVAL '30 days'
      ORDER BY d.expiry_date ASC
    `);

    const escape = (val) => {
      if (val == null) return "";
      const str = String(val);
      if (str.includes(",") || str.includes('"') || str.includes("\n"))
        return `"${str.replace(/"/g, '""')}"`;
      return str;
    };

    const headers = ["Owner Name", "Company", "Document Name", "Document Type", "Expiry Date", "Owner Type"];
    const csv = [
      headers.join(","),
      ...rows.rows.map(r => [
        escape(r.owner_name),
        escape(r.company_name || (r.entity_type === "company" ? r.owner_name : "")),
        escape(r.document_name),
        escape(r.document_type),
        escape(r.expiry_date ? new Date(r.expiry_date).toLocaleDateString("en-IN") : ""),
        escape(r.entity_type === "company" ? "Company" : "Employee"),
      ].join(","))
    ].join("\n");

    const filename = `expiring-documents-${new Date().toISOString().split("T")[0]}.csv`;
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(csv);
  } catch (e) {
    err(res, e.message);
  }
};
