const { pool } = require("../db");
const path = require("path");

const ok = (res, data, status = 200) =>
  res.status(status).json({ success: true, data });

const err = (res, message, status = 500) =>
  res.status(status).json({ success: false, message });

// GET /companies/search?name=&pageNumber=0&pageSize=10&sortBy=id&sortDirection=ASC
exports.searchCompanies = async (req, res) => {
  try {
    const { name = "", pageNumber = 0, pageSize = 10, sortBy = "id", sortDirection = "ASC" } = req.query;
    const offset = parseInt(pageNumber) * parseInt(pageSize);
    const allowedSort = ["id", "name", "industry", "created_at"];
    const col = allowedSort.includes(sortBy) ? sortBy : "id";
    const dir = sortDirection.toUpperCase() === "DESC" ? "DESC" : "ASC";
    const orderExpr = col === "name" ? `LOWER(c.name) ${dir}` : `${col} ${dir}`;

    const countRes = await pool.query(
      "SELECT COUNT(*) FROM companies WHERE LOWER(name) LIKE LOWER($1)",
      [`%${name}%`]
    );
    const total = parseInt(countRes.rows[0].count);

    const rows = await pool.query(
      `SELECT c.*, (SELECT COUNT(*) FROM employees e WHERE e.company_id = c.id) AS "employeeCount"
       FROM companies c
       WHERE LOWER(c.name) LIKE LOWER($1)
       ORDER BY ${orderExpr}
       LIMIT $2 OFFSET $3`,
      [`%${name}%`, parseInt(pageSize), offset]
    );

    ok(res, {
      content: rows.rows,
      totalElements: total,
      totalPages: Math.ceil(total / pageSize),
      pageNumber: parseInt(pageNumber),
    });
  } catch (e) {
    err(res, e.message);
  }
};

// GET /companies/:id
exports.getCompanyById = async (req, res) => {
  try {
    const { id } = req.params;
    const row = await pool.query(
      `SELECT c.*, (SELECT COUNT(*) FROM employees e WHERE e.company_id = c.id) AS "employeeCount"
       FROM companies c WHERE c.id = $1`,
      [id]
    );
    if (!row.rows.length) return err(res, "Company not found", 404);
    ok(res, row.rows[0]);
  } catch (e) {
    err(res, e.message);
  }
};

// POST /companies
exports.createCompany = async (req, res) => {
  try {
    const { name, registrationNumber, email, phone, address, industry } = req.body;
    if (!name) return err(res, "Name is required", 400);

    const row = await pool.query(
      `INSERT INTO companies (name, registration_number, email, phone, address, industry)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [name, registrationNumber, email, phone, address, industry]
    );
    ok(res, row.rows[0], 201);
  } catch (e) {
    err(res, e.message);
  }
};

// PUT /companies/:id
exports.updateCompany = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, registrationNumber, email, phone, address, industry, status } = req.body;
    const row = await pool.query(
      `UPDATE companies SET
        name=COALESCE($1,name), registration_number=COALESCE($2,registration_number),
        email=COALESCE($3,email), phone=COALESCE($4,phone), address=COALESCE($5,address),
        industry=COALESCE($6,industry), status=COALESCE($7,status), updated_at=NOW()
       WHERE id=$8 RETURNING *`,
      [name, registrationNumber, email, phone, address, industry, status, id]
    );
    if (!row.rows.length) return err(res, "Company not found", 404);
    ok(res, row.rows[0]);
  } catch (e) {
    err(res, e.message);
  }
};

// DELETE /companies/:id
exports.deleteCompany = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query("DELETE FROM companies WHERE id=$1", [id]);
    ok(res, { message: "Deleted" });
  } catch (e) {
    err(res, e.message);
  }
};

// POST /companies/:id/logo  (multipart)
exports.uploadLogo = async (req, res) => {
  try {
    const { id } = req.params;
    if (!req.file) return err(res, "No file uploaded", 400);
    const filePath = req.file.path;
    await pool.query("UPDATE companies SET logo_path=$1 WHERE id=$2", [filePath, id]);
    ok(res, { logoPath: filePath });
  } catch (e) {
    err(res, e.message);
  }
};
