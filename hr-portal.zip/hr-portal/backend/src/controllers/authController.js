const jwt = require("jsonwebtoken");

const ok = (res, data, status = 200) =>
  res.status(status).json({ success: true, data });
const err = (res, message, status = 401) =>
  res.status(status).json({ success: false, message });

// POST /auth/login
exports.login = (req, res) => {
  const { username, password } = req.body;

  const validUsername = process.env.APP_USERNAME || "admin";
  const validPassword = process.env.APP_PASSWORD || "safeway123";

  if (username !== validUsername || password !== validPassword) {
    return err(res, "Invalid username or password");
  }

  const token = jwt.sign(
    { username },
    process.env.JWT_SECRET || "safeway_jwt_secret",
    { expiresIn: "12h" }
  );

  ok(res, { token, username });
};

// GET /auth/verify
exports.verify = (req, res) => {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith("Bearer ")) {
    return err(res, "No token provided");
  }
  try {
    const token = auth.split(" ")[1];
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET || "safeway_jwt_secret"
    );
    ok(res, { username: decoded.username });
  } catch {
    err(res, "Invalid or expired token");
  }
};
