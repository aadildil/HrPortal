const { pool } = require("../db");

const ok = (res, data) => res.status(200).json({ success: true, data });
const err = (res, message, status = 500) => res.status(status).json({ success: false, message });

const escape = (val) => {
  if (val == null) return "";
  const str = String(val);
  if (str.includes(",") || str.includes('"') || str.includes("\n"))
    return `"${str.replace(/"/g, '""')}"`;
  return str;
};

// GET /reports/company?companyId=&status=&fromDate=&toDate=
exports.getCompanyReport = async (req, res) => {
  try {
    const { companyId, status, fromDate, toDate } = req.query;

    // Build employee query
    const empConditions = ["e.deleted_at IS NULL"];
    const empParams = [];

    if (companyId) { empParams.push(companyId); empConditions.push(`e.company_id=$${empParams.length}`); }
    if (status) { empParams.push(status); empConditions.push(`e.status=$${empParams.length}`); }
    if (fromDate) { empParams.push(fromDate); empConditions.push(`e.joined_at>=$${empParams.length}`); }
    if (toDate) { empParams.push(toDate); empConditions.push(`e.joined_at<=$${empParams.length}`); }

    const empWhere = empConditions.length ? "WHERE " + empConditions.join(" AND ") : "";

    const employees = await pool.query(
      `SELECT e.*, c.name as company_name
       FROM employees e
       JOIN companies c ON e.company_id = c.id
       ${empWhere}
       ORDER BY c.name, e.name`,
      empParams
    );

    // Build docs query
    const docConditions = ["d.entity_type='company'"];
    const docParams = [];

    if (companyId) { docParams.push(companyId); docConditions.push(`d.entity_id=$${docParams.length}`); }
    if (fromDate) { docParams.push(fromDate); docConditions.push(`d.uploaded_at::date>=$${docParams.length}`); }
    if (toDate) { docParams.push(toDate); docConditions.push(`d.uploaded_at::date<=$${docParams.length}`); }

    const docWhere = "WHERE " + docConditions.join(" AND ");

    const docs = await pool.query(
      `SELECT d.*, c.name as company_name
       FROM documents d
       JOIN companies c ON d.entity_id = c.id
       ${docWhere}
       ORDER BY c.name, d.uploaded_at DESC`,
      docParams
    );

    ok(res, { employees: employees.rows, documents: docs.rows });
  } catch (e) {
    err(res, e.message);
  }
};

// GET /reports/employee?companyId=&employeeId=&department=&status=
exports.getEmployeeReport = async (req, res) => {
  try {
    const { companyId, employeeId, department, status } = req.query;

    const empConditions = ["e.deleted_at IS NULL"];
    const empParams = [];

    if (companyId) { empParams.push(companyId); empConditions.push(`e.company_id=$${empParams.length}`); }
    if (employeeId) { empParams.push(employeeId); empConditions.push(`e.id=$${empParams.length}`); }
    if (department) { empParams.push(`%${department}%`); empConditions.push(`e.department ILIKE $${empParams.length}`); }
    if (status) { empParams.push(status); empConditions.push(`e.status=$${empParams.length}`); }

    const empWhere = "WHERE " + empConditions.join(" AND ");

    const employees = await pool.query(
      `SELECT e.*, c.name as company_name
       FROM employees e
       JOIN companies c ON e.company_id = c.id
       ${empWhere}
       ORDER BY c.name, e.name`,
      empParams
    );

    // Get employee IDs for doc lookup
    const empIds = employees.rows.map(e => e.id);
    let docs = { rows: [] };
    if (empIds.length > 0) {
      docs = await pool.query(
        `SELECT d.*, e.name as employee_name, c.name as company_name
         FROM documents d
         JOIN employees e ON d.entity_id = e.id
         JOIN companies c ON e.company_id = c.id
         WHERE d.entity_type='employee' AND d.entity_id = ANY($1)
         ORDER BY e.name, d.uploaded_at DESC`,
        [empIds]
      );
    }

    ok(res, { employees: employees.rows, documents: docs.rows });
  } catch (e) {
    err(res, e.message);
  }
};

// GET /reports/company-csv?...
exports.downloadCompanyCSV = async (req, res) => {
  try {
    const { companyId, status, fromDate, toDate, type } = req.query;

    if (type === "employees") {
      const conditions = ["e.deleted_at IS NULL"];
      const params = [];
      if (companyId) { params.push(companyId); conditions.push(`e.company_id=$${params.length}`); }
      if (status) { params.push(status); conditions.push(`e.status=$${params.length}`); }
      if (fromDate) { params.push(fromDate); conditions.push(`e.joined_at>=$${params.length}`); }
      if (toDate) { params.push(toDate); conditions.push(`e.joined_at<=$${params.length}`); }

      const rows = await pool.query(
        `SELECT e.name, e.employee_code, e.company_employee_code, e.designation, e.department,
                e.email, e.phone, e.salary, e.status, e.joined_at, c.name as company_name
         FROM employees e JOIN companies c ON e.company_id = c.id
         WHERE ${conditions.join(" AND ")}
         ORDER BY c.name, e.name`,
        params
      );

      const headers = ["Name", "System Code", "Company Code", "Designation", "Department", "Email", "Phone", "Salary", "Status", "Joined Date", "Company"];
      const csv = [headers.join(","), ...rows.rows.map(r => [
        escape(r.name), escape(r.employee_code), escape(r.company_employee_code),
        escape(r.designation), escape(r.department), escape(r.email), escape(r.phone),
        escape(r.salary), escape(r.status),
        escape(r.joined_at ? new Date(r.joined_at).toLocaleDateString("en-IN") : ""),
        escape(r.company_name)
      ].join(","))].join("\n");

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="company-employees-report.csv"`);
      return res.send(csv);
    }

    if (type === "documents") {
      const conditions = ["d.entity_type='company'"];
      const params = [];
      if (companyId) { params.push(companyId); conditions.push(`d.entity_id=$${params.length}`); }
      if (fromDate) { params.push(fromDate); conditions.push(`d.uploaded_at::date>=$${params.length}`); }
      if (toDate) { params.push(toDate); conditions.push(`d.uploaded_at::date<=$${params.length}`); }

      const rows = await pool.query(
        `SELECT d.document_name, d.document_type, d.expiry_date, d.uploaded_at, c.name as company_name
         FROM documents d JOIN companies c ON d.entity_id = c.id
         WHERE ${conditions.join(" AND ")}
         ORDER BY c.name, d.uploaded_at DESC`,
        params
      );

      const headers = ["Document Name", "Type", "Expiry Date", "Uploaded On", "Company"];
      const csv = [headers.join(","), ...rows.rows.map(r => [
        escape(r.document_name), escape(r.document_type),
        escape(r.expiry_date ? new Date(r.expiry_date).toLocaleDateString("en-IN") : ""),
        escape(r.uploaded_at ? new Date(r.uploaded_at).toLocaleDateString("en-IN") : ""),
        escape(r.company_name)
      ].join(","))].join("\n");

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="company-documents-report.csv"`);
      return res.send(csv);
    }

    err(res, "Invalid type parameter", 400);
  } catch (e) {
    err(res, e.message);
  }
};

// GET /reports/employee-csv?...
exports.downloadEmployeeCSV = async (req, res) => {
  try {
    const { companyId, employeeId, department, status, type } = req.query;

    const conditions = ["e.deleted_at IS NULL"];
    const params = [];
    if (companyId) { params.push(companyId); conditions.push(`e.company_id=$${params.length}`); }
    if (employeeId) { params.push(employeeId); conditions.push(`e.id=$${params.length}`); }
    if (department) { params.push(`%${department}%`); conditions.push(`e.department ILIKE $${params.length}`); }
    if (status) { params.push(status); conditions.push(`e.status=$${params.length}`); }

    if (type === "employees") {
      const rows = await pool.query(
        `SELECT e.name, e.employee_code, e.company_employee_code, e.designation, e.department,
                e.email, e.phone, e.salary, e.status, e.joined_at, c.name as company_name
         FROM employees e JOIN companies c ON e.company_id = c.id
         WHERE ${conditions.join(" AND ")}
         ORDER BY c.name, e.name`,
        params
      );

      const headers = ["Name", "System Code", "Company Code", "Designation", "Department", "Email", "Phone", "Salary", "Status", "Joined Date", "Company"];
      const csv = [headers.join(","), ...rows.rows.map(r => [
        escape(r.name), escape(r.employee_code), escape(r.company_employee_code),
        escape(r.designation), escape(r.department), escape(r.email), escape(r.phone),
        escape(r.salary), escape(r.status),
        escape(r.joined_at ? new Date(r.joined_at).toLocaleDateString("en-IN") : ""),
        escape(r.company_name)
      ].join(","))].join("\n");

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="employee-report.csv"`);
      return res.send(csv);
    }

    if (type === "documents") {
      const empRows = await pool.query(
        `SELECT e.id FROM employees e WHERE ${conditions.join(" AND ")}`, params
      );
      const empIds = empRows.rows.map(e => e.id);
      if (!empIds.length) {
        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", `attachment; filename="employee-documents-report.csv"`);
        return res.send("Employee Name,Company,Document Name,Type,Expiry Date,Uploaded On\n");
      }

      const rows = await pool.query(
        `SELECT d.document_name, d.document_type, d.expiry_date, d.uploaded_at,
                e.name as employee_name, c.name as company_name
         FROM documents d
         JOIN employees e ON d.entity_id = e.id
         JOIN companies c ON e.company_id = c.id
         WHERE d.entity_type='employee' AND d.entity_id = ANY($1)
         ORDER BY e.name, d.uploaded_at DESC`,
        [empIds]
      );

      const headers = ["Employee Name", "Company", "Document Name", "Type", "Expiry Date", "Uploaded On"];
      const csv = [headers.join(","), ...rows.rows.map(r => [
        escape(r.employee_name), escape(r.company_name), escape(r.document_name),
        escape(r.document_type),
        escape(r.expiry_date ? new Date(r.expiry_date).toLocaleDateString("en-IN") : ""),
        escape(r.uploaded_at ? new Date(r.uploaded_at).toLocaleDateString("en-IN") : "")
      ].join(","))].join("\n");

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="employee-documents-report.csv"`);
      return res.send(csv);
    }

    err(res, "Invalid type parameter", 400);
  } catch (e) {
    err(res, e.message);
  }
};
