const { pool } = require("../db");

const ok = (res, data, status = 200) =>
  res.status(status).json({ success: true, data });
const err = (res, message, status = 500) =>
  res.status(status).json({ success: false, message });

// POST /employees/search  (body: { criteria: { companyId, showDeleted }, pageRequest: {...} })
exports.searchEmployees = async (req, res) => {
  try {
    const { criteria = {}, pageRequest = {} } = req.body;
    const { companyId, showDeleted = false } = criteria;
    const { pageNumber = 0, pageSize = 10, sortBy = "id", sortDirection = "ASC" } = pageRequest;
    const offset = parseInt(pageNumber) * parseInt(pageSize);
    const allowedSort = ["id", "name", "department", "designation", "joined_at"];
    const col = allowedSort.includes(sortBy) ? sortBy : "id";
    const dir = sortDirection.toUpperCase() === "DESC" ? "DESC" : "ASC";

    // Build WHERE clause
    const conditions = [];
    const params = [];

    if (companyId) {
      params.push(companyId);
      conditions.push(`company_id=$${params.length}`);
    }

    if (showDeleted) {
      conditions.push("deleted_at IS NOT NULL");
    } else {
      conditions.push("deleted_at IS NULL");
    }

    const whereClause = conditions.length ? "WHERE " + conditions.join(" AND ") : "";

    const countRes = await pool.query(
      `SELECT COUNT(*) FROM employees ${whereClause}`,
      params
    );
    const total = parseInt(countRes.rows[0].count);

    const rows = await pool.query(
      `SELECT * FROM employees ${whereClause}
       ORDER BY ${col} ${dir}
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, parseInt(pageSize), offset]
    );

    ok(res, {
      content: rows.rows,
      totalElements: total,
      totalPages: Math.ceil(total / pageSize),
      pageNumber: parseInt(pageNumber),
    });
  } catch (e) {
    err(res, e.message);
  }
};

// GET /employees/:id
exports.getEmployeeById = async (req, res) => {
  try {
    const { id } = req.params;
    const row = await pool.query("SELECT * FROM employees WHERE id=$1", [id]);
    if (!row.rows.length) return err(res, "Employee not found", 404);
    ok(res, row.rows[0]);
  } catch (e) {
    err(res, e.message);
  }
};

// POST /employees
exports.createEmployee = async (req, res) => {
  try {
    const {
      companyId, name, email, phone, designation,
      department, salary, status, joinedAt, employeeCode,
      companyEmployeeCode
    } = req.body;

    if (!companyId || !name) return err(res, "companyId and name are required", 400);

    const code = employeeCode || `EMP-${Date.now()}`;

    const row = await pool.query(
      `INSERT INTO employees
        (company_id, employee_code, company_employee_code, name, email, phone, designation, department, salary, status, joined_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [companyId, code, companyEmployeeCode || null, name, email, phone, designation, department, salary, status || "Active", joinedAt || null]
    );
    ok(res, row.rows[0], 201);
  } catch (e) {
    err(res, e.message);
  }
};

// PUT /employees/:id
exports.updateEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, phone, designation, department, salary, status, joinedAt, companyEmployeeCode } = req.body;
    const row = await pool.query(
      `UPDATE employees SET
        name=COALESCE($1,name), email=COALESCE($2,email), phone=COALESCE($3,phone),
        designation=COALESCE($4,designation), department=COALESCE($5,department),
        salary=COALESCE($6,salary), status=COALESCE($7,status),
        joined_at=COALESCE($8,joined_at),
        company_employee_code=COALESCE($9,company_employee_code),
        updated_at=NOW()
       WHERE id=$10 RETURNING *`,
      [name, email, phone, designation, department, salary, status, joinedAt, companyEmployeeCode, id]
    );
    if (!row.rows.length) return err(res, "Employee not found", 404);
    ok(res, row.rows[0]);
  } catch (e) {
    err(res, e.message);
  }
};

// DELETE /employees/:id  (soft delete — sets deleted_at)
exports.deleteEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    const row = await pool.query(
      "UPDATE employees SET deleted_at=NOW(), status='Inactive' WHERE id=$1 RETURNING *",
      [id]
    );
    if (!row.rows.length) return err(res, "Employee not found", 404);
    ok(res, { message: "Employee moved to former employees" });
  } catch (e) {
    err(res, e.message);
  }
};

// POST /employees/:id/restore
exports.restoreEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    const row = await pool.query(
      "UPDATE employees SET deleted_at=NULL, status='Active' WHERE id=$1 RETURNING *",
      [id]
    );
    if (!row.rows.length) return err(res, "Employee not found", 404);
    ok(res, row.rows[0]);
  } catch (e) {
    err(res, e.message);
  }
};

// POST /employees/:id/photo  (multipart)
exports.uploadPhoto = async (req, res) => {
  try {
    const { id } = req.params;
    if (!req.file) return err(res, "No file uploaded", 400);
    await pool.query("UPDATE employees SET photo_path=$1 WHERE id=$2", [req.file.path, id]);
    ok(res, { photoPath: req.file.path });
  } catch (e) {
    err(res, e.message);
  }
};
