const jwt = require("jsonwebtoken");

module.exports = function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  // Also accept token from query param (needed for iframe previews)
  const queryToken = req.query.token;
  const token = queryToken || (auth && auth.startsWith("Bearer ") ? auth.split(" ")[1] : null);

  if (!token) {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "safeway_jwt_secret");
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ success: false, message: "Invalid or expired token" });
  }
};
