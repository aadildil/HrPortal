require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const { initDB } = require("./db");
const routes = require("./routes");

const app = express();
const PORT = process.env.PORT || 8001;

app.use(cors({ origin: "*" }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const uploadDir = process.env.UPLOAD_DIR || "./uploads";
app.use("/uploads", express.static(uploadDir));

app.use("/api/v1", routes);
app.get("/health", (_req, res) => res.json({ status: "ok" }));

const start = async () => {
  let retries = 10;
  while (retries > 0) {
    try {
      await initDB();
      break;
    } catch (e) {
      retries--;
      console.log(`DB not ready, retrying... (${retries} left)`);
      await new Promise((r) => setTimeout(r, 3000));
    }
  }
  app.listen(PORT, () => {
    console.log(`🚀 Safeway Vault API running on http://localhost:${PORT}`);
  });
};

start();
