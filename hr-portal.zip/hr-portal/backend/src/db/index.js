const { Pool } = require("pg");

const pool = new Pool({
  host: process.env.DB_HOST || "localhost",
  port: parseInt(process.env.DB_PORT || "5432"),
  database: process.env.DB_NAME || "hrportal",
  user: process.env.DB_USER || "hruser",
  password: process.env.DB_PASSWORD || "hrpassword",
});

const initDB = async () => {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS companies (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        registration_number VARCHAR(100),
        email VARCHAR(255),
        phone VARCHAR(50),
        address TEXT,
        industry VARCHAR(100),
        status VARCHAR(50) DEFAULT 'Active',
        logo_path VARCHAR(500),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS employees (
        id SERIAL PRIMARY KEY,
        company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
        employee_code VARCHAR(100) UNIQUE,
        company_employee_code VARCHAR(100),
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255),
        phone VARCHAR(50),
        designation VARCHAR(100),
        department VARCHAR(100),
        salary NUMERIC(12,2),
        status VARCHAR(50) DEFAULT 'Active',
        joined_at DATE,
        photo_path VARCHAR(500),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        deleted_at TIMESTAMP DEFAULT NULL
      );

      -- Migration: add deleted_at if it doesn't exist yet (for existing installs)
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP DEFAULT NULL;
      ALTER TABLE employees ADD COLUMN IF NOT EXISTS company_employee_code VARCHAR(100);

      CREATE TABLE IF NOT EXISTS documents (
        id SERIAL PRIMARY KEY,
        entity_type VARCHAR(20) NOT NULL CHECK (entity_type IN ('company','employee')),
        entity_id INTEGER NOT NULL,
        document_name VARCHAR(255) NOT NULL,
        document_type VARCHAR(100),
        file_path VARCHAR(500) NOT NULL,
        file_original_name VARCHAR(255),
        expiry_date DATE,
        uploaded_at TIMESTAMP DEFAULT NOW()
      );
    `);
    console.log("✅ Database tables ready");
  } finally {
    client.release();
  }
};

module.exports = { pool, initDB };
