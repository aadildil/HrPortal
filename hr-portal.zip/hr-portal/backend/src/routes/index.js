const express = require("express");
const router = express.Router();
const upload = require("../middleware/upload");
const auth = require("../middleware/auth");

const authCtrl = require("../controllers/authController");
const companyCtrl = require("../controllers/companyController");
const employeeCtrl = require("../controllers/employeeController");
const docCtrl = require("../controllers/documentController");

const reportCtrl = require("../controllers/reportController");

// ── Auth (public) ──────────────────────────────────
router.post("/auth/login", authCtrl.login);
router.get("/auth/verify", authCtrl.verify);

// ── Companies (protected) ──────────────────────────
router.get("/companies/search", auth, companyCtrl.searchCompanies);
router.get("/companies/:id", auth, companyCtrl.getCompanyById);
router.post("/companies", auth, companyCtrl.createCompany);
router.put("/companies/:id", auth, companyCtrl.updateCompany);
router.delete("/companies/:id", auth, companyCtrl.deleteCompany);
router.post("/companies/:entityId/logo", auth,
  (req, _res, next) => { req.params.entityType = "companies"; next(); },
  upload.single("file"), companyCtrl.uploadLogo
);

// ── Employees (protected) ──────────────────────────
router.post("/employees/search", auth, employeeCtrl.searchEmployees);
router.get("/employees/:id", auth, employeeCtrl.getEmployeeById);
router.post("/employees", auth, employeeCtrl.createEmployee);
router.put("/employees/:id", auth, employeeCtrl.updateEmployee);
router.delete("/employees/:id", auth, employeeCtrl.deleteEmployee);
router.post("/employees/:id/restore", auth, employeeCtrl.restoreEmployee);
router.post("/employees/:entityId/photo", auth,
  (req, _res, next) => { req.params.entityType = "employees"; next(); },
  upload.single("file"), employeeCtrl.uploadPhoto
);

// ── Documents (protected) ──────────────────────────
router.get("/documents/expiring-csv", auth, docCtrl.exportExpiringCSV);
router.get("/documents", auth, docCtrl.getDocuments);
router.post("/documents/bulk", auth,
  (req, _res, next) => {
    req.params.entityType = req.body.entityType;
    req.params.entityId = req.body.entityId;
    next();
  },
  upload.array("files", 20),
  docCtrl.uploadDocumentsBulk
);
router.post("/documents", auth,
  (req, _res, next) => {
    req.params.entityType = req.body.entityType;
    req.params.entityId = req.body.entityId;
    next();
  },
  upload.single("file"), docCtrl.uploadDocument
);
router.get("/documents/:id/download", auth, docCtrl.downloadDocument);
router.get("/documents/:id/preview", auth, docCtrl.previewDocument);
router.delete("/documents/:id", auth, docCtrl.deleteDocument);

// ── Reports (protected) ───────────────────────────
router.get("/reports/company", auth, reportCtrl.getCompanyReport);
router.get("/reports/employee", auth, reportCtrl.getEmployeeReport);
router.get("/reports/company-csv", auth, reportCtrl.downloadCompanyCSV);
router.get("/reports/employee-csv", auth, reportCtrl.downloadEmployeeCSV);

module.exports = router;
