#!/bin/bash
cd "$(dirname "$0")"

echo ""
echo " ================================"
echo "     Safeway HR Portal"
echo " ================================"
echo ""

if ! docker info > /dev/null 2>&1; then
    echo " Docker is not running. Opening Docker Desktop..."
    open -a Docker
    echo " Waiting for Docker to start..."
    sleep 30
fi

until docker info > /dev/null 2>&1; do
    sleep 5
done

echo " Starting Safeway HR Portal..."
docker compose up -d --build

sleep 5

echo " Opening in browser..."
open http://localhost:3000

echo ""
echo " ================================"
echo "  Safeway HR Portal is running!"
echo "  http://localhost:3000"
echo " ================================"
echo ""
