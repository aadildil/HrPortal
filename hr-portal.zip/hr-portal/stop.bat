@echo off
title HR Portal - Stop
echo.
echo  Stopping HR Portal...
docker compose down
echo  HR Portal stopped. Your data is saved.
echo.
pause
