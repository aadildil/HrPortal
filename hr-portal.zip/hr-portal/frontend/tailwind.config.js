/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        primaryBlue: "#1E3A8A",
        offwhite: "#F8F9FA",
        searchGray: "#F1F3F5",
        placeholderGray: "#9CA3AF",
      },
    },
  },
  plugins: [],
};
