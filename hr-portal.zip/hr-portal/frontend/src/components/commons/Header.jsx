import { useNavigate } from "react-router-dom";
import { FiShield, FiSun, FiMoon, FiLogOut, FiUser } from "react-icons/fi";
import { logout, getUser } from "../../services/authService";

export default function Header({ darkMode, setDarkMode, onLogout }) {
  const navigate = useNavigate();
  const user = getUser();

  const handleLogout = () => {
    logout();
    onLogout();
  };

  return (
    <header className="sticky top-0 z-50 bg-primaryBlue text-white px-6 py-4 flex justify-between items-center shadow">
      <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate("/")}>
        <FiShield size={20} />
        <span className="font-bold text-lg tracking-tight" style={{ fontFamily: "Georgia, serif" }}>
          SAFEWAY <span className="font-light opacity-80 text-base">Vault</span>
        </span>
      </div>

      <div className="flex items-center gap-3">
        {user && (
          <div className="flex items-center gap-1.5 text-sm text-white/70">
            <FiUser size={13} />
            <span>{user}</span>
          </div>
        )}

        <button
          onClick={() => setDarkMode(!darkMode)}
          className="bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-lg text-sm flex items-center gap-2 transition"
        >
          {darkMode ? <FiSun size={14} /> : <FiMoon size={14} />}
          {darkMode ? "Light" : "Dark"}
        </button>

        <button
          onClick={handleLogout}
          className="bg-white/10 hover:bg-red-500/60 text-white px-3 py-1.5 rounded-lg text-sm flex items-center gap-2 transition"
          title="Logout"
        >
          <FiLogOut size={14} /> Logout
        </button>
      </div>
    </header>
  );
}
