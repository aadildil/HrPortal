import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { deleteDocument } from "../../services/documentService";
import { FiDownload, FiTrash2, FiFileText, FiPlus, FiEye, FiX } from "react-icons/fi";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8001/api/v1";

const isPreviewable = (filename) => {
  if (!filename) return false;
  const ext = filename.split(".").pop().toLowerCase();
  return ["pdf", "png", "jpg", "jpeg", "gif", "webp"].includes(ext);
};

const downloadFile = (id) => {
  const token = localStorage.getItem("sw_token");
  fetch(`${API_BASE}/documents/${id}/download`, {
    headers: { Authorization: `Bearer ${token}` }
  }).then(res => res.blob()).then(blob => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "";
    a.click();
    URL.revokeObjectURL(url);
  });
};

function PreviewModal({ doc, onClose }) {
  const token = localStorage.getItem("sw_token");
  const previewUrl = `${API_BASE}/documents/${doc.id}/preview`;
  const ext = (doc.file_original_name || "").split(".").pop().toLowerCase();
  const isImage = ["png", "jpg", "jpeg", "gif", "webp"].includes(ext);
  const isPdf = ext === "pdf";
  const [blobUrl, setBlobUrl] = useState(null);

  useEffect(() => {
    // Fetch with auth token and create blob URL
    fetch(previewUrl, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.blob())
      .then(blob => setBlobUrl(URL.createObjectURL(blob)))
      .catch(console.error);
    return () => { if (blobUrl) URL.revokeObjectURL(blobUrl); };
  }, [doc.id]);

  return (
    <motion.div
      className="fixed inset-0 bg-black/80 flex flex-col z-[9999] p-4"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <FiFileText className="text-white" size={16} />
          <span className="text-white font-medium text-sm truncate max-w-xs">{doc.document_name}</span>
          {doc.document_type && (
            <span className="text-xs bg-white/20 text-white px-2 py-0.5 rounded-full">{doc.document_type}</span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => downloadFile(doc.id)}
            className="flex items-center gap-1.5 text-xs bg-white/20 hover:bg-white/30 text-white px-3 py-1.5 rounded-lg transition"
          >
            <FiDownload size={13} /> Download
          </button>
          <button
            onClick={onClose}
            className="text-white/70 hover:text-white bg-white/10 hover:bg-white/20 p-2 rounded-lg transition"
          >
            <FiX size={18} />
          </button>
        </div>
      </div>

      {/* Preview area */}
      <div className="flex-1 bg-gray-900 rounded-xl overflow-hidden flex items-center justify-center">
        {!blobUrl && (
          <div className="text-white/40 text-sm animate-pulse">Loading preview…</div>
        )}
        {blobUrl && isPdf && (
          <iframe
            src={blobUrl}
            className="w-full h-full rounded-xl"
            title={doc.document_name}
          />
        )}
        {blobUrl && isImage && (
          <img
            src={blobUrl}
            alt={doc.document_name}
            className="max-w-full max-h-full object-contain rounded"
          />
        )}
      </div>
    </motion.div>
  );
}

export default function DocumentTable({ title, documents, onAdd, onRefresh }) {
  const [deleting, setDeleting] = useState(null);
  const [previewDoc, setPreviewDoc] = useState(null);

  const handleDelete = async (id) => {
    if (!confirm("Delete this document?")) return;
    setDeleting(id);
    try {
      await deleteDocument(id);
      onRefresh();
    } catch (e) {
      console.error(e);
    } finally {
      setDeleting(null);
    }
  };

  return (
    <>
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
        <div className="flex justify-between items-center mb-5">
          <h2 className="text-base font-semibold text-primaryBlue">{title} ({documents.length})</h2>
          <button
            onClick={onAdd}
            className="flex items-center gap-2 bg-primaryBlue text-white px-4 py-2 rounded-lg hover:bg-blue-900 transition text-sm"
          >
            <FiPlus size={14} /> Add Document
          </button>
        </div>

        {documents.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <FiFileText size={32} className="mx-auto mb-2 opacity-30" />
            <p className="text-sm">No documents uploaded yet</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 dark:border-gray-700 text-xs uppercase tracking-wider text-gray-400">
                  <th className="pb-3 text-left font-medium pl-2">Document Name</th>
                  <th className="pb-3 text-left font-medium">Type</th>
                  <th className="pb-3 text-left font-medium">Expiry</th>
                  <th className="pb-3 text-left font-medium">Uploaded</th>
                  <th className="pb-3 text-left font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {documents.map((doc) => (
                  <motion.tr
                    key={doc.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="border-b border-gray-50 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition"
                  >
                    <td className="py-3 pl-2 flex items-center gap-2">
                      <FiFileText className="text-primaryBlue shrink-0" size={14} />
                      <span className="font-medium truncate max-w-[180px]">{doc.document_name}</span>
                    </td>
                    <td className="py-3">
                      <span className="text-xs bg-blue-50 dark:bg-blue-900/30 text-primaryBlue px-2 py-0.5 rounded-full">
                        {doc.document_type || "—"}
                      </span>
                    </td>
                    <td className="py-3 text-gray-500 text-xs">
                      {doc.expiry_date
                        ? (() => {
                            const expiry = new Date(doc.expiry_date);
                            const today = new Date();
                            const daysLeft = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
                            return (
                              <span className={daysLeft < 0 ? "text-red-500" : daysLeft <= 30 ? "text-orange-500" : ""}>
                                {expiry.toLocaleDateString()}
                                {daysLeft < 0 && " (Expired)"}
                                {daysLeft >= 0 && daysLeft <= 30 && ` (${daysLeft}d left)`}
                              </span>
                            );
                          })()
                        : <span className="text-gray-300">—</span>}
                    </td>
                    <td className="py-3 text-gray-400 text-xs">
                      {new Date(doc.uploaded_at).toLocaleDateString()}
                    </td>
                    <td className="py-3">
                      <div className="flex items-center gap-1">
                        {isPreviewable(doc.file_original_name) && (
                          <button
                            onClick={() => setPreviewDoc(doc)}
                            className="text-primaryBlue hover:text-blue-900 transition p-1.5 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20"
                            title="Preview"
                          >
                            <FiEye size={15} />
                          </button>
                        )}
                        <button
                          onClick={() => downloadFile(doc.id)}
                          className="text-primaryBlue hover:text-blue-900 transition p-1.5 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20"
                          title="Download"
                        >
                          <FiDownload size={15} />
                        </button>
                        <button
                          onClick={() => handleDelete(doc.id)}
                          disabled={deleting === doc.id}
                          className="text-red-400 hover:text-red-600 transition p-1.5 rounded hover:bg-red-50 dark:hover:bg-red-900/20 disabled:opacity-40"
                          title="Delete"
                        >
                          <FiTrash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Preview Modal */}
      <AnimatePresence>
        {previewDoc && (
          <PreviewModal doc={previewDoc} onClose={() => setPreviewDoc(null)} />
        )}
      </AnimatePresence>
    </>
  );
}
