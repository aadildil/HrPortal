import { useState } from "react";
import { deleteDocument, downloadDocument } from "../../services/documentService";
import { FiDownload, FiTrash2, FiFileText, FiPlus } from "react-icons/fi";

export default function DocumentTable({ title, documents, onAdd, onRefresh }) {
  const [deleting, setDeleting] = useState(null);

  const handleDelete = async (id) => {
    if (!confirm("Delete this document?")) return;
    setDeleting(id);
    try {
      await deleteDocument(id);
      onRefresh();
    } catch (e) {
      console.error(e);
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
      <div className="flex justify-between items-center mb-5">
        <h2 className="text-base font-semibold text-primaryBlue">{title} ({documents.length})</h2>
        <button
          onClick={onAdd}
          className="flex items-center gap-2 bg-primaryBlue text-white px-4 py-2 rounded-lg hover:bg-blue-900 transition text-sm"
        >
          <FiPlus size={14} /> Add Document
        </button>
      </div>

      {documents.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          <FiFileText size={32} className="mx-auto mb-2 opacity-30" />
          <p className="text-sm">No documents uploaded yet</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 dark:border-gray-700 text-xs uppercase tracking-wider text-gray-400">
                <th className="pb-3 text-left font-medium pl-2">Document Name</th>
                <th className="pb-3 text-left font-medium">Type</th>
                <th className="pb-3 text-left font-medium">Expiry</th>
                <th className="pb-3 text-left font-medium">Uploaded</th>
                <th className="pb-3 text-left font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {documents.map((doc) => (
                <tr key={doc.id} className="border-b border-gray-50 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition">
                  <td className="py-3 pl-2 flex items-center gap-2">
                    <FiFileText className="text-primaryBlue shrink-0" size={14} />
                    <span className="font-medium truncate max-w-[180px]">{doc.document_name}</span>
                  </td>
                  <td className="py-3">
                    <span className="text-xs bg-blue-50 dark:bg-blue-900/30 text-primaryBlue px-2 py-0.5 rounded-full">
                      {doc.document_type || "—"}
                    </span>
                  </td>
                  <td className="py-3 text-gray-500 text-xs">
                    {doc.expiry_date
                      ? new Date(doc.expiry_date).toLocaleDateString()
                      : <span className="text-gray-300">—</span>}
                  </td>
                  <td className="py-3 text-gray-400 text-xs">
                    {new Date(doc.uploaded_at).toLocaleDateString()}
                  </td>
                  <td className="py-3">
                    <div className="flex items-center gap-2">
                      <a
                        href={downloadDocument(doc.id)}
                        target="_blank"
                        rel="noreferrer"
                        className="text-primaryBlue hover:text-blue-900 transition p-1 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20"
                        title="Download"
                      >
                        <FiDownload size={15} />
                      </a>
                      <button
                        onClick={() => handleDelete(doc.id)}
                        disabled={deleting === doc.id}
                        className="text-red-400 hover:text-red-600 transition p-1 rounded hover:bg-red-50 dark:hover:bg-red-900/20 disabled:opacity-40"
                        title="Delete"
                      >
                        <FiTrash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
