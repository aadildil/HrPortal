import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function SplashScreen({ onComplete }) {
  const [phase, setPhase] = useState("intro"); // intro → logo → tagline → out

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("logo"), 300);
    const t2 = setTimeout(() => setPhase("tagline"), 1200);
    const t3 = setTimeout(() => setPhase("out"), 2600);
    const t4 = setTimeout(() => onComplete(), 3200);
    return () => [t1, t2, t3, t4].forEach(clearTimeout);
  }, []);

  return (
    <AnimatePresence>
      {phase !== "done" && (
        <motion.div
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center"
          style={{ background: "linear-gradient(135deg, #0f1f5c 0%, #1E3A8A 50%, #1a56c4 100%)" }}
          initial={{ opacity: 1 }}
          animate={{ opacity: phase === "out" ? 0 : 1 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
        >
          {/* Animated background rings */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {[1, 2, 3].map((i) => (
              <motion.div
                key={i}
                className="absolute rounded-full border border-white/5"
                style={{
                  width: `${i * 280}px`,
                  height: `${i * 280}px`,
                  top: "50%",
                  left: "50%",
                  x: "-50%",
                  y: "-50%",
                }}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: i * 0.15, duration: 1.2, ease: "easeOut" }}
              />
            ))}
          </div>

          {/* Logo mark */}
          <motion.div
            className="relative mb-6"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{
              scale: phase === "intro" ? 0.5 : 1,
              opacity: phase === "intro" ? 0 : 1,
            }}
            transition={{ duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
          >
            {/* Shield shape */}
            <div className="w-20 h-20 relative flex items-center justify-center">
              <svg viewBox="0 0 80 80" className="w-20 h-20 absolute">
                <path
                  d="M40 4 L72 18 L72 42 C72 58 56 70 40 76 C24 70 8 58 8 42 L8 18 Z"
                  fill="none"
                  stroke="rgba(255,255,255,0.9)"
                  strokeWidth="2"
                />
                <path
                  d="M40 4 L72 18 L72 42 C72 58 56 70 40 76 C24 70 8 58 8 42 L8 18 Z"
                  fill="rgba(255,255,255,0.08)"
                />
              </svg>
              <span className="relative z-10 text-white font-bold text-2xl tracking-tight">S</span>
            </div>
          </motion.div>

          {/* App name */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{
              y: phase === "intro" ? 20 : 0,
              opacity: phase === "intro" ? 0 : 1,
            }}
            transition={{ delay: 0.2, duration: 0.6, ease: "easeOut" }}
            className="text-center"
          >
            <h1
              className="text-5xl font-bold text-white tracking-widest mb-1"
              style={{ fontFamily: "Georgia, serif", letterSpacing: "0.2em" }}
            >
              SAFEWAY
            </h1>
            <div className="w-32 h-px bg-white/30 mx-auto mb-3" />
            <p className="text-blue-200 text-sm tracking-[0.3em] uppercase">Vault</p>
          </motion.div>

          {/* Tagline */}
          <motion.p
            className="absolute bottom-16 text-white/40 text-xs tracking-widest uppercase"
            initial={{ opacity: 0 }}
            animate={{ opacity: phase === "tagline" || phase === "out" ? 1 : 0 }}
            transition={{ duration: 0.8 }}
          >
            Secure · Store · Safeguard
          </motion.p>

          {/* Loading bar */}
          <motion.div
            className="absolute bottom-8 w-32 h-0.5 bg-white/10 rounded-full overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <motion.div
              className="h-full bg-white/60 rounded-full"
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 2, ease: "easeInOut" }}
            />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
