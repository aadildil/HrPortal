import { motion, AnimatePresence } from "framer-motion";
import { useState, useRef } from "react";
import { uploadDocumentsBulk } from "../../services/documentService";
import { FiX, FiUpload, FiTrash2, FiFile } from "react-icons/fi";

const DOC_TYPES = ["ID Proof", "Contract", "Offer Letter", "Certificate", "Invoice", "Registration", "Other"];

const formatSize = (bytes) => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

export default function AddDocumentModal({ entityType, entityId, onClose, onSuccess }) {
  const [files, setFiles] = useState([]); // [{ file, documentName, documentType, expiryDate }]
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef();

  const addFiles = (newFiles) => {
    const allowed = [".pdf", ".jpg", ".jpeg", ".png", ".doc", ".docx", ".xlsx"];
    const valid = Array.from(newFiles).filter(f => {
      const ext = "." + f.name.split(".").pop().toLowerCase();
      return allowed.includes(ext) && f.size <= 20 * 1024 * 1024;
    });
    setFiles(prev => [
      ...prev,
      ...valid.map(f => ({
        file: f,
        documentName: f.name.replace(/\.[^/.]+$/, ""),
        documentType: "Other",
        expiryDate: "",
      }))
    ]);
  };

  const removeFile = (i) => setFiles(prev => prev.filter((_, idx) => idx !== i));

  const updateMeta = (i, key, value) => {
    setFiles(prev => prev.map((f, idx) => idx === i ? { ...f, [key]: value } : f));
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    addFiles(e.dataTransfer.files);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (files.length === 0) { setError("Please select at least one file"); return; }
    setLoading(true); setError("");
    try {
      const fd = new FormData();
      fd.append("entityType", entityType);
      fd.append("entityId", String(entityId));
      files.forEach(f => fd.append("files", f.file));
      fd.append("metadata", JSON.stringify(files.map(f => ({
        documentName: f.documentName,
        documentType: f.documentType,
        expiryDate: f.expiryDate,
      }))));
      await uploadDocumentsBulk(fd);
      onSuccess();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const inputCls = "border rounded-lg px-2 py-1.5 text-xs dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-1 focus:ring-primaryBlue w-full";

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 flex justify-center items-center z-50 p-4"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        className="bg-white dark:bg-gray-800 p-6 rounded-xl w-full max-w-2xl shadow-2xl max-h-[90vh] flex flex-col"
        initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-primaryBlue">Upload Documents</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition"><FiX size={20} /></button>
        </div>

        {error && <p className="text-red-500 text-sm mb-3 bg-red-50 dark:bg-red-900/20 p-2 rounded">{error}</p>}

        {/* Drop Zone */}
        <div
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          onClick={() => inputRef.current.click()}
          className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition mb-4 ${
            dragging
              ? "border-primaryBlue bg-blue-50 dark:bg-blue-900/20"
              : "border-gray-200 dark:border-gray-600 hover:border-primaryBlue hover:bg-blue-50/30 dark:hover:bg-blue-900/10"
          }`}
        >
          <FiUpload className="mx-auto text-gray-400 mb-2" size={24} />
          <p className="text-sm text-gray-500">
            Drag & drop files here or <span className="text-primaryBlue font-medium">browse</span>
          </p>
          <p className="text-xs text-gray-400 mt-1">PDF, Word, Excel, Images — max 20MB each</p>
          <input
            ref={inputRef}
            type="file"
            multiple
            className="hidden"
            accept=".pdf,.doc,.docx,.xlsx,.jpg,.jpeg,.png"
            onChange={(e) => addFiles(e.target.files)}
          />
        </div>

        {/* File list with per-file metadata */}
        {files.length > 0 && (
          <div className="flex-1 overflow-y-auto space-y-3 mb-4">
            <p className="text-xs text-gray-400 font-medium uppercase tracking-wider">
              {files.length} file{files.length > 1 ? "s" : ""} selected — set details for each
            </p>
            <AnimatePresence>
              {files.map((f, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-3 border border-gray-100 dark:border-gray-600"
                >
                  {/* File header */}
                  <div className="flex items-center gap-2 mb-3">
                    <FiFile className="text-primaryBlue shrink-0" size={16} />
                    <span className="text-xs text-gray-500 truncate flex-1">{f.file.name}</span>
                    <span className="text-xs text-gray-400 shrink-0">{formatSize(f.file.size)}</span>
                    <button
                      type="button"
                      onClick={() => removeFile(i)}
                      className="text-red-400 hover:text-red-600 transition shrink-0"
                    >
                      <FiTrash2 size={14} />
                    </button>
                  </div>

                  {/* Per-file metadata */}
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-xs text-gray-400 mb-1">Document Name</label>
                      <input
                        className={inputCls}
                        value={f.documentName}
                        onChange={e => updateMeta(i, "documentName", e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-400 mb-1">Document Type</label>
                      <select
                        className={inputCls}
                        value={f.documentType}
                        onChange={e => updateMeta(i, "documentType", e.target.value)}
                      >
                        {DOC_TYPES.map(t => <option key={t}>{t}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs text-gray-400 mb-1">Expiry Date</label>
                      <input
                        type="date"
                        className={inputCls}
                        value={f.expiryDate}
                        onChange={e => updateMeta(i, "expiryDate", e.target.value)}
                      />
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        <div className="flex justify-between items-center pt-2 border-t border-gray-100 dark:border-gray-700">
          <button
            type="button"
            onClick={() => inputRef.current.click()}
            className="text-sm text-primaryBlue hover:underline"
          >
            + Add more files
          </button>
          <div className="flex gap-2">
            <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition">
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              disabled={loading || files.length === 0}
              className="px-4 py-2 bg-primaryBlue text-white rounded-lg text-sm hover:bg-blue-900 transition disabled:opacity-60"
            >
              {loading ? `Uploading ${files.length} file${files.length > 1 ? "s" : ""}…` : `Upload ${files.length > 0 ? files.length : ""} File${files.length !== 1 ? "s" : ""}`}
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
