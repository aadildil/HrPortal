import { motion } from "framer-motion";
import { useState } from "react";
import { uploadDocument } from "../../services/documentService";
import { FiX, FiUpload } from "react-icons/fi";

const DOC_TYPES = ["ID Proof", "Contract", "Offer Letter", "Certificate", "Invoice", "Registration", "Other"];

export default function AddDocumentModal({ entityType, entityId, onClose, onSuccess }) {
  const [form, setForm] = useState({ documentName: "", documentType: "Other", expiryDate: "" });
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) { setError("Please select a file"); return; }
    setLoading(true); setError("");
    try {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("entityType", entityType);
      fd.append("entityId", String(entityId));
      fd.append("documentName", form.documentName || file.name);
      fd.append("documentType", form.documentType);
      if (form.expiryDate) fd.append("expiryDate", form.expiryDate);
      await uploadDocument(fd);
      onSuccess();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 flex justify-center items-center z-50 p-4"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        className="bg-white dark:bg-gray-800 p-6 rounded-xl w-full max-w-md shadow-2xl"
        initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
      >
        <div className="flex justify-between items-center mb-5">
          <h2 className="text-xl font-bold text-primaryBlue">Upload Document</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition"><FiX size={20} /></button>
        </div>

        {error && <p className="text-red-500 text-sm mb-3 bg-red-50 dark:bg-red-900/20 p-2 rounded">{error}</p>}

        <form className="space-y-4" onSubmit={handleSubmit}>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Document Name</label>
            <input
              value={form.documentName}
              onChange={e => setForm({ ...form, documentName: e.target.value })}
              placeholder="Leave blank to use filename"
              className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Document Type</label>
            <select
              value={form.documentType}
              onChange={e => setForm({ ...form, documentType: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue"
            >
              {DOC_TYPES.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Expiry Date (optional)</label>
            <input
              type="date"
              value={form.expiryDate}
              onChange={e => setForm({ ...form, expiryDate: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">File *</label>
            <label className="flex flex-col items-center justify-center w-full h-28 border-2 border-dashed rounded-xl cursor-pointer hover:border-primaryBlue transition dark:border-gray-600 hover:bg-blue-50/50 dark:hover:bg-blue-900/10">
              <FiUpload className="text-gray-400 mb-2" size={22} />
              {file ? (
                <span className="text-sm text-primaryBlue font-medium px-4 text-center truncate max-w-full">{file.name}</span>
              ) : (
                <span className="text-sm text-gray-400">PDF, Word, Excel, Image (max 20MB)</span>
              )}
              <input type="file" className="hidden" onChange={e => setFile(e.target.files[0])} />
            </label>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition">Cancel</button>
            <button type="submit" disabled={loading} className="px-4 py-2 bg-primaryBlue text-white rounded-lg text-sm hover:bg-blue-900 transition disabled:opacity-60">
              {loading ? "Uploading…" : "Upload"}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
