import { motion } from "framer-motion";
import { useState } from "react";
import { createCompany } from "../../services/companyService";
import { FiX } from "react-icons/fi";

const FIELDS = [
  ["name", "Company Name", "text", true],
  ["registrationNumber", "Registration Number", "text", false],
  ["email", "Email", "email", false],
  ["phone", "Phone", "tel", false],
  ["address", "Address", "text", false],
  ["industry", "Industry", "text", false],
];

export default function AddCompanyModal({ onClose, onSuccess }) {
  const [form, setForm] = useState({ name:"", registrationNumber:"", email:"", phone:"", address:"", industry:"" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setError("");
    try {
      await createCompany(form);
      onSuccess();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 flex justify-center items-center z-50 p-4"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        className="bg-white dark:bg-gray-800 p-6 rounded-xl w-full max-w-md shadow-2xl"
        initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
      >
        <div className="flex justify-between items-center mb-5">
          <h2 className="text-xl font-bold text-primaryBlue">Add Company</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition"><FiX size={20} /></button>
        </div>

        {error && <p className="text-red-500 text-sm mb-3 bg-red-50 dark:bg-red-900/20 p-2 rounded">{error}</p>}

        <form className="space-y-3" onSubmit={handleSubmit}>
          {FIELDS.map(([key, label, type, required]) => (
            <div key={key}>
              <label className="block text-xs text-gray-400 mb-1">{label}{required && " *"}</label>
              <input
                type={type}
                name={key}
                value={form[key]}
                onChange={e => setForm({ ...form, [key]: e.target.value })}
                required={required}
                className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue"
              />
            </div>
          ))}
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition">Cancel</button>
            <button type="submit" disabled={loading} className="px-4 py-2 bg-primaryBlue text-white rounded-lg text-sm hover:bg-blue-900 transition disabled:opacity-60">
              {loading ? "Adding…" : "Add Company"}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
