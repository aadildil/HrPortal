import { motion } from "framer-motion";
import { useState } from "react";
import { updateEmployee } from "../../services/EmployeeService";
import { FiX } from "react-icons/fi";

export default function EditEmployeeModal({ employee, onClose, onSuccess }) {
  const [form, setForm] = useState({
    name: employee.name || "",
    email: employee.email || "",
    phone: employee.phone || "",
    designation: employee.designation || "",
    department: employee.department || "",
    salary: employee.salary || "",
    status: employee.status || "Active",
    joinedAt: employee.joined_at ? employee.joined_at.split("T")[0] : "",
    companyEmployeeCode: employee.company_employee_code || "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setError("");
    try {
      await updateEmployee(employee.id, form);
      onSuccess();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 flex justify-center items-center z-50 p-4"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        className="bg-white dark:bg-gray-800 p-6 rounded-xl w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto"
        initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
      >
        <div className="flex justify-between items-center mb-5">
          <h2 className="text-xl font-bold text-primaryBlue">Edit Employee</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition"><FiX size={20} /></button>
        </div>

        {error && <p className="text-red-500 text-sm mb-3 bg-red-50 dark:bg-red-900/20 p-2 rounded">{error}</p>}

        <form className="space-y-3" onSubmit={handleSubmit}>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="block text-xs text-gray-400 mb-1">Full Name *</label>
              <input required value={form.name} onChange={set("name")} className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue" />
            </div>
            <div className="col-span-2">
              <label className="block text-xs text-gray-400 mb-1">Company Employee Code</label>
              <input value={form.companyEmployeeCode} onChange={set("companyEmployeeCode")} placeholder="e.g. ABC-001" className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Email</label>
              <input type="email" value={form.email} onChange={set("email")} className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Phone</label>
              <input type="tel" value={form.phone} onChange={set("phone")} className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Designation</label>
              <input value={form.designation} onChange={set("designation")} className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Department</label>
              <input value={form.department} onChange={set("department")} className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Salary</label>
              <input type="number" value={form.salary} onChange={set("salary")} className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Joining Date</label>
              <input type="date" value={form.joinedAt} onChange={set("joinedAt")} className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue" />
            </div>
            <div className="col-span-2">
              <label className="block text-xs text-gray-400 mb-1">Status</label>
              <select value={form.status} onChange={set("status")} className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue">
                <option>Active</option>
                <option>Inactive</option>
                <option>On Leave</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="px-4 py-2 border rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition">Cancel</button>
            <button type="submit" disabled={loading} className="px-4 py-2 bg-primaryBlue text-white rounded-lg text-sm hover:bg-blue-900 transition disabled:opacity-60">
              {loading ? "Saving…" : "Save Changes"}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
