import { useEffect, useState } from "react";
import { motion } from "framer-motion";

const API = import.meta.env.VITE_API_URL
  ? import.meta.env.VITE_API_URL.replace("/api/v1", "")
  : "http://localhost:8001";

export default function LicenseGate({ children }) {
  const [status, setStatus] = useState("checking"); // checking | valid | invalid
  const [machineId, setMachineId] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    const check = async () => {
      try {
        const res = await fetch(`${API}/license-status`);
        const data = await res.json();
        setMachineId(data.machineId || "");
        setMessage(data.message || "");
        setStatus(data.valid ? "valid" : "invalid");
      } catch {
        setStatus("invalid");
        setMessage("Cannot connect to the application server.");
      }
    };
    check();
  }, []);

  if (status === "checking") {
    return (
      <div className="fixed inset-0 flex items-center justify-center"
        style={{ background: "linear-gradient(135deg, #0f1f5c, #1E3A8A)" }}>
        <div className="text-white/60 text-sm tracking-widest animate-pulse uppercase">
          Verifying license…
        </div>
      </div>
    );
  }

  if (status === "invalid") {
    return (
      <div className="fixed inset-0 flex items-center justify-center p-6"
        style={{ background: "linear-gradient(135deg, #0f1f5c, #1E3A8A)" }}>
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl p-8 max-w-md w-full text-center"
        >
          {/* Shield with X */}
          <div className="w-16 h-16 mx-auto mb-5 relative flex items-center justify-center">
            <svg viewBox="0 0 80 80" className="w-16 h-16 absolute">
              <path
                d="M40 4 L72 18 L72 42 C72 58 56 70 40 76 C24 70 8 58 8 42 L8 18 Z"
                fill="#FEE2E2" stroke="#EF4444" strokeWidth="2"
              />
            </svg>
            <span className="relative z-10 text-red-500 font-bold text-2xl">✕</span>
          </div>

          <h1 className="text-xl font-bold text-gray-800 dark:text-white mb-1">
            License Required
          </h1>
          <p className="text-xs text-blue-400 tracking-widest uppercase mb-4">Safeway Vault</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
            This copy of Safeway HR Portal is not licensed for this machine.
          </p>

          {machineId && (
            <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4 mb-5 text-left">
              <p className="text-xs text-gray-400 uppercase tracking-wider mb-2">Your Machine ID</p>
              <p className="font-mono text-xs text-gray-700 dark:text-gray-300 break-all select-all">
                {machineId}
              </p>
              <p className="text-xs text-gray-400 mt-2">
                Share this with your vendor to get a license key.
              </p>
            </div>
          )}

          <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-3 mb-5">
            <p className="text-xs text-red-500">{message}</p>
          </div>

          <p className="text-xs text-gray-400">
            Once you have a license key, add it to your <span className="font-mono bg-gray-100 dark:bg-gray-700 px-1 rounded">.env</span> file as <span className="font-mono bg-gray-100 dark:bg-gray-700 px-1 rounded">LICENSE_KEY=...</span> and restart the app.
          </p>
        </motion.div>
      </div>
    );
  }

  return children;
}
