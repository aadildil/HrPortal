import { api } from "../api/httpClient";

export const searchEmployeesByCompanyId = ({ companyId, pageNumber = 0, pageSize = 50, showDeleted = false } = {}) =>
  api.post("/employees/search", {
    criteria: { companyId, showDeleted },
    pageRequest: { pageNumber, pageSize, sortBy: "id", sortDirection: "ASC" },
  });

export const getEmployeeById = (id) => api.get(`/employees/${id}`);

export const createEmployee = (data) => api.post("/employees", data);

export const updateEmployee = (id, data) => api.put(`/employees/${id}`, data);

export const deleteEmployee = (id) => api.delete(`/employees/${id}`);

export const restoreEmployee = (id) => api.post(`/employees/${id}/restore`);
