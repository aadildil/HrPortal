const BASE = import.meta.env.VITE_API_URL || "http://localhost:8001/api/v1";

export async function login(username, password) {
  const res = await fetch(`${BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || "Login failed");
  return json.data;
}

export async function verifyToken() {
  const token = localStorage.getItem("sw_token");
  if (!token) return false;
  try {
    const res = await fetch(`${BASE}/auth/verify`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.ok;
  } catch {
    return false;
  }
}

export function logout() {
  localStorage.removeItem("sw_token");
  localStorage.removeItem("sw_user");
}

export function getUser() {
  return localStorage.getItem("sw_user");
}
