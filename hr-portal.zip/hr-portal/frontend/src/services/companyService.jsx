import { api } from "../api/httpClient";

export const searchCompanies = ({ name = "", pageNumber = 0, pageSize = 10, sortBy = "id", sortDirection = "ASC" } = {}) =>
  api.get(`/companies/search?name=${encodeURIComponent(name)}&pageNumber=${pageNumber}&pageSize=${pageSize}&sortBy=${sortBy}&sortDirection=${sortDirection}`);

export const getCompanyById = (id) => api.get(`/companies/${id}`);

export const createCompany = (data) => api.post("/companies", data);

export const updateCompany = (id, data) => api.put(`/companies/${id}`, data);

export const deleteCompany = (id) => api.delete(`/companies/${id}`);
