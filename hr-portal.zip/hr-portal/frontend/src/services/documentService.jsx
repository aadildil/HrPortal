import { api } from "../api/httpClient";

export const getDocuments = (entityType, entityId) =>
  api.get(`/documents?entityType=${entityType}&entityId=${entityId}`);

export const uploadDocument = (formData) => api.upload("/documents", formData);

export const uploadDocumentsBulk = (formData) => {
  const BASE = import.meta.env.VITE_API_URL || "http://localhost:8001/api/v1";
  const token = localStorage.getItem("sw_token");
  return fetch(`${BASE}/documents/bulk`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    body: formData,
  }).then(async (res) => {
    const json = await res.json();
    if (!res.ok) throw new Error(json.message || "Upload failed");
    return json.data;
  });
};

export const getDocumentUrl = (id, type = "download") => {
  const BASE = import.meta.env.VITE_API_URL || "http://localhost:8001/api/v1";
  const token = localStorage.getItem("sw_token");
  return { url: `${BASE}/documents/${id}/${type}`, token };
};

export const deleteDocument = (id) => api.delete(`/documents/${id}`);
