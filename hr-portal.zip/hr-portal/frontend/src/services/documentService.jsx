import { api } from "../api/httpClient";

export const getDocuments = (entityType, entityId) =>
  api.get(`/documents?entityType=${entityType}&entityId=${entityId}`);

export const uploadDocument = (formData) => api.upload("/documents", formData);

export const downloadDocument = (id) =>
  `${import.meta.env.VITE_API_URL || "http://localhost:8001/api/v1"}/documents/${id}/download`;

export const deleteDocument = (id) => api.delete(`/documents/${id}`);
