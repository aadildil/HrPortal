import { Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";
import Layout from "./layout/Layout";
import Dashboard from "./pages/Dashboard";
import CompanyDetails from "./pages/CompanyDetails";
import EmployeeDetails from "./pages/EmployeeDetails";
import Login from "./pages/Login";
import SplashScreen from "./components/SplashScreen";
import { verifyToken, getUser } from "./services/authService";

export default function App() {
  const [splashDone, setSplashDone] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const check = async () => {
      const valid = await verifyToken();
      setIsLoggedIn(valid);
      setChecking(false);
    };
    check();
  }, []);

  const handleLogin = () => setIsLoggedIn(true);
  const handleLogout = () => setIsLoggedIn(false);

  if (!splashDone) {
    return <SplashScreen onComplete={() => setSplashDone(true)} />;
  }

  if (checking) {
    return (
      <div className="fixed inset-0 flex items-center justify-center"
        style={{ background: "linear-gradient(135deg, #0f1f5c, #1E3A8A)" }}>
        <div className="text-white/60 text-sm tracking-widest animate-pulse uppercase">
          Loading…
        </div>
      </div>
    );
  }

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <Routes>
      <Route element={<Layout onLogout={handleLogout} />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/company/:id" element={<CompanyDetails />} />
        <Route path="/company/:id/employee/:empId" element={<EmployeeDetails />} />
      </Route>
    </Routes>
  );
}
