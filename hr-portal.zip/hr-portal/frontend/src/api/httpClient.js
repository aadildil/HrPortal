const BASE = import.meta.env.VITE_API_URL || "http://localhost:8001/api/v1";

async function request(method, path, body, isFormData = false) {
  const token = localStorage.getItem("sw_token");
  const headers = isFormData
    ? {}
    : { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: isFormData ? body : body ? JSON.stringify(body) : undefined,
  });

  if (res.status === 401) {
    localStorage.removeItem("sw_token");
    localStorage.removeItem("sw_user");
    window.location.href = "/";
    return;
  }

  const json = await res.json();
  if (!res.ok) throw new Error(json.message || "Request failed");
  return json.data;
}

export const api = {
  get: (path) => request("GET", path),
  post: (path, body) => request("POST", path, body),
  put: (path, body) => request("PUT", path, body),
  delete: (path) => request("DELETE", path),
  upload: (path, formData) => request("POST", path, formData, true),
};

export const UPLOAD_BASE = import.meta.env.VITE_API_URL
  ? import.meta.env.VITE_API_URL.replace("/api/v1", "")
  : "http://localhost:8001";
