import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { searchCompanies } from "../services/companyService";
import AddCompanyModal from "../components/modals/AddCompanyModal";
import EditCompanyModal from "../components/modals/EditCompanyModal";
import { FiPlus, FiSearch, FiBriefcase, FiUsers, FiDownload, FiAlertCircle, FiEdit2, FiChevronLeft, FiChevronRight } from "react-icons/fi";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8001/api/v1";
const PAGE_SIZE = 12;

export default function Dashboard() {
  const navigate = useNavigate();
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddCompany, setShowAddCompany] = useState(false);
  const [editCompany, setEditCompany] = useState(null);
  const [search, setSearch] = useState("");
  const [exporting, setExporting] = useState(false);
  const [exportMsg, setExportMsg] = useState("");
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);

  const fetchCompanies = async (name = "", pageNumber = 0) => {
    setLoading(true);
    try {
      const data = await searchCompanies({ name, pageNumber, pageSize: PAGE_SIZE, sortBy: "name", sortDirection: "ASC" });
      setCompanies(data.content || []);
      setTotalPages(data.totalPages || 0);
      setTotalElements(data.totalElements || 0);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchCompanies(); }, []);

  const handleSearch = (e) => {
    setSearch(e.target.value);
    setPage(0);
    fetchCompanies(e.target.value, 0);
  };

  const handlePageChange = (newPage) => {
    setPage(newPage);
    fetchCompanies(search, newPage);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleExportExpiring = async () => {
    setExporting(true);
    setExportMsg("");
    try {
      const token = localStorage.getItem("sw_token");
      const res = await fetch(`${API_BASE}/documents/expiring-csv`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) throw new Error("Export failed");
      const text = await res.text();
      const lines = text.trim().split("\n");
      if (lines.length <= 1) {
        setExportMsg("No documents expiring in the next 30 days.");
        return;
      }
      const blob = new Blob([text], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `expiring-documents-${new Date().toISOString().split("T")[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      setExportMsg("Failed to export. Make sure the server is running.");
    } finally {
      setExporting(false);
      setTimeout(() => setExportMsg(""), 4000);
    }
  };

  return (
    <>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-primaryBlue">Companies</h1>
          <p className="text-gray-500 text-sm mt-1">{totalElements} registered</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={handleExportExpiring}
            disabled={exporting}
            className="flex items-center gap-2 border border-orange-400 text-orange-500 px-4 py-2 rounded-lg hover:bg-orange-50 dark:hover:bg-orange-900/20 transition text-sm disabled:opacity-60"
          >
            <FiAlertCircle size={15} />
            {exporting ? "Exporting…" : "Expiring Certificates"}
            {!exporting && <FiDownload size={14} />}
          </button>
          <button
            onClick={() => setShowAddCompany(true)}
            className="flex items-center gap-2 bg-primaryBlue text-white px-4 py-2 rounded-lg hover:bg-blue-900 transition text-sm"
          >
            <FiPlus size={16} /> Add Company
          </button>
        </div>
      </div>

      {exportMsg && (
        <div className="mb-4 flex items-center gap-2 text-sm text-orange-600 bg-orange-50 dark:bg-orange-900/20 dark:text-orange-400 px-4 py-2 rounded-lg border border-orange-200 dark:border-orange-800">
          <FiAlertCircle size={15} /> {exportMsg}
        </div>
      )}

      <div className="relative mb-6">
        <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          value={search}
          onChange={handleSearch}
          placeholder="Search companies..."
          className="w-full pl-10 pr-4 py-2 border rounded-lg bg-white dark:bg-gray-800 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-primaryBlue"
        />
      </div>

      {loading ? (
        <div className="grid md:grid-cols-3 gap-6">
          {[1,2,3].map(i => (
            <div key={i} className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow animate-pulse h-36" />
          ))}
        </div>
      ) : companies.length === 0 ? (
        <div className="text-center py-20 text-gray-400">
          <FiBriefcase size={48} className="mx-auto mb-4 opacity-30" />
          <p className="text-lg">No companies found</p>
          <p className="text-sm mt-1">Add your first company to get started</p>
        </div>
      ) : (
        <>
          <div className="grid md:grid-cols-3 gap-6">
            {companies.map((company, i) => (
              <motion.div
                key={company.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className="relative bg-white dark:bg-gray-800 p-6 rounded-xl shadow hover:shadow-lg transition-all duration-200 border border-transparent hover:border-primaryBlue"
              >
                <button
                  onClick={(e) => { e.stopPropagation(); setEditCompany(company); }}
                  className="absolute top-4 right-4 text-gray-400 hover:text-primaryBlue p-1.5 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 transition"
                  title="Edit company"
                >
                  <FiEdit2 size={14} />
                </button>
                <div className="cursor-pointer" onClick={() => navigate(`/company/${company.id}`)}>
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center text-primaryBlue font-bold text-lg">
                      {company.name?.charAt(0).toUpperCase()}
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium mr-7 ${
                      company.status === "Active"
                        ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                        : "bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400"
                    }`}>
                      {company.status}
                    </span>
                  </div>
                  <h2 className="text-lg font-bold text-primaryBlue truncate">{company.name}</h2>
                  <p className="text-sm text-gray-500 mt-1">{company.industry || "—"}</p>
                  <div className="flex items-center gap-1 mt-3 text-sm text-gray-500">
                    <FiUsers size={14} />
                    <span>{company.employeeCount || 0} employees</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-8">
              <p className="text-sm text-gray-500">
                Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, totalElements)} of {totalElements} companies
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handlePageChange(page - 1)}
                  disabled={page === 0}
                  className="flex items-center gap-1 px-3 py-2 border rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <FiChevronLeft size={16} /> Previous
                </button>

                {/* Page numbers */}
                <div className="flex items-center gap-1">
                  {Array.from({ length: totalPages }, (_, i) => i).map(p => (
                    <button
                      key={p}
                      onClick={() => handlePageChange(p)}
                      className={`w-8 h-8 rounded-lg text-sm transition ${
                        p === page
                          ? "bg-primaryBlue text-white"
                          : "hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600"
                      }`}
                    >
                      {p + 1}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => handlePageChange(page + 1)}
                  disabled={page >= totalPages - 1}
                  className="flex items-center gap-1 px-3 py-2 border rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-700 transition disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Next <FiChevronRight size={16} />
                </button>
              </div>
            </div>
          )}
        </>
      )}

      <AnimatePresence>
        {showAddCompany && (
          <AddCompanyModal
            onClose={() => setShowAddCompany(false)}
            onSuccess={() => { fetchCompanies(search, page); setShowAddCompany(false); }}
          />
        )}
        {editCompany && (
          <EditCompanyModal
            company={editCompany}
            onClose={() => setEditCompany(null)}
            onSuccess={() => { fetchCompanies(search, page); setEditCompany(null); }}
            onDelete={() => { fetchCompanies(search, 0); setPage(0); setEditCompany(null); navigate("/"); }}
          />
        )}
      </AnimatePresence>
    </>
  );
}
