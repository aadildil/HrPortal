import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { getCompanyById } from "../services/companyService";
import { searchEmployeesByCompanyId, deleteEmployee, restoreEmployee } from "../services/EmployeeService";
import { getDocuments } from "../services/documentService";
import AddDocumentModal from "../components/modals/AddDocumentModal";
import AddEmployeeModal from "../components/modals/AddEmployeeModal";
import DocumentTable from "../components/tables/DocumentTable";
import {
  FiArrowLeft, FiPlus, FiMail, FiPhone, FiMapPin,
  FiHash, FiGrid, FiTrash2, FiRefreshCw, FiChevronDown, FiChevronUp, FiSearch
} from "react-icons/fi";

export default function CompanyDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [company, setCompany] = useState(null);
  const [employees, setEmployees] = useState([]);
  const [formerEmployees, setFormerEmployees] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDocModal, setShowDocModal] = useState(false);
  const [showEmpModal, setShowEmpModal] = useState(false);
  const [showFormer, setShowFormer] = useState(false);
  const [actionId, setActionId] = useState(null);
  const [empSearch, setEmpSearch] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const [c, e, fe, d] = await Promise.all([
        getCompanyById(id),
        searchEmployeesByCompanyId({ companyId: Number(id), showDeleted: false }),
        searchEmployeesByCompanyId({ companyId: Number(id), showDeleted: true }),
        getDocuments("company", id),
      ]);
      setCompany(c);
      setEmployees(e.content || []);
      setFormerEmployees(fe.content || []);
      setDocuments(d || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [id]);

  // Client-side filtering across name, department, designation, code
  const filteredEmployees = employees.filter((emp) => {
    const q = empSearch.toLowerCase();
    if (!q) return true;
    return (
      emp.name?.toLowerCase().includes(q) ||
      emp.department?.toLowerCase().includes(q) ||
      emp.designation?.toLowerCase().includes(q) ||
      emp.company_employee_code?.toLowerCase().includes(q) ||
      emp.employee_code?.toLowerCase().includes(q) ||
      emp.email?.toLowerCase().includes(q) ||
      emp.phone?.toLowerCase().includes(q)
    );
  });

  const handleDelete = async (empId, name) => {
    if (!confirm(`Remove ${name} from active employees?\nThey will appear in the Former Employees section.`)) return;
    setActionId(empId);
    try {
      await deleteEmployee(empId);
      load();
    } catch (e) {
      console.error(e);
    } finally {
      setActionId(null);
    }
  };

  const handleRestore = async (empId, name) => {
    if (!confirm(`Restore ${name} as an active employee?`)) return;
    setActionId(empId);
    try {
      await restoreEmployee(empId);
      load();
    } catch (e) {
      console.error(e);
    } finally {
      setActionId(null);
    }
  };

  if (loading) return (
    <div className="space-y-4 animate-pulse p-6">
      <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-48" />
      <div className="h-40 bg-gray-200 dark:bg-gray-700 rounded-xl" />
      <div className="h-40 bg-gray-200 dark:bg-gray-700 rounded-xl" />
    </div>
  );

  if (!company) return <div className="p-6 text-red-500">Company not found.</div>;

  const EmployeeRow = ({ emp, isFormer }) => (
    <motion.tr
      key={emp.id}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className={`border-b border-gray-50 dark:border-gray-700/50 transition ${
        isFormer
          ? "opacity-60 hover:opacity-80"
          : "hover:bg-blue-50/50 dark:hover:bg-gray-700/30 cursor-pointer"
      }`}
    >
      <td
        className={`py-3 pl-2 font-medium ${isFormer ? "text-gray-400 line-through" : "text-primaryBlue hover:underline cursor-pointer"}`}
        onClick={() => !isFormer && navigate(`/company/${id}/employee/${emp.id}`)}
      >
        {emp.name}
      </td>
      <td className="py-3 text-gray-500 font-mono text-xs">{emp.company_employee_code || emp.employee_code}</td>
      <td className="py-3 text-gray-600 dark:text-gray-300">{emp.department || "—"}</td>
      <td className="py-3 text-gray-600 dark:text-gray-300">{emp.designation || "—"}</td>
      <td className="py-3">
        <span className={`text-xs px-2 py-0.5 rounded-full ${
          isFormer
            ? "bg-red-100 text-red-500 dark:bg-red-900/30 dark:text-red-400"
            : emp.status === "Active"
              ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
              : "bg-gray-100 text-gray-500"
        }`}>
          {isFormer ? "Former" : emp.status}
        </span>
      </td>
      <td className="py-3 text-gray-500">{emp.phone || emp.email || "—"}</td>
      <td className="py-3">
        {isFormer ? (
          <button
            onClick={() => handleRestore(emp.id, emp.name)}
            disabled={actionId === emp.id}
            title="Restore employee"
            className="flex items-center gap-1 text-xs text-green-500 hover:text-green-700 border border-green-200 dark:border-green-800 px-2 py-1 rounded hover:bg-green-50 dark:hover:bg-green-900/20 transition disabled:opacity-40"
          >
            <FiRefreshCw size={12} /> Restore
          </button>
        ) : (
          <button
            onClick={() => handleDelete(emp.id, emp.name)}
            disabled={actionId === emp.id}
            title="Remove employee"
            className="text-red-400 hover:text-red-600 p-1.5 rounded hover:bg-red-50 dark:hover:bg-red-900/20 transition disabled:opacity-40"
          >
            <FiTrash2 size={14} />
          </button>
        )}
      </td>
    </motion.tr>
  );

  const tableHeaders = (
    <tr className="border-b border-gray-100 dark:border-gray-700 text-gray-400 text-xs uppercase tracking-wider">
      <th className="pb-3 text-left font-medium pl-2">Name</th>
      <th className="pb-3 text-left font-medium">Code</th>
      <th className="pb-3 text-left font-medium">Department</th>
      <th className="pb-3 text-left font-medium">Designation</th>
      <th className="pb-3 text-left font-medium">Status</th>
      <th className="pb-3 text-left font-medium">Contact</th>
      <th className="pb-3 text-left font-medium">Action</th>
    </tr>
  );

  return (
    <div className="space-y-6">
      {/* Back + Title */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="text-gray-400 hover:text-primaryBlue transition">
          <FiArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-primaryBlue">{company.name}</h1>
          <p className="text-sm text-gray-500">{company.industry}</p>
        </div>
        <span className={`ml-auto text-xs px-3 py-1 rounded-full font-medium ${
          company.status === "Active"
            ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
            : "bg-gray-100 text-gray-500"
        }`}>{company.status}</span>
      </div>

      {/* Company Info */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">Company Info</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          {company.registration_number && (
            <div className="flex items-center gap-2 text-sm">
              <FiHash className="text-primaryBlue shrink-0" />
              <span className="text-gray-500">Reg No:</span>
              <span className="font-medium">{company.registration_number}</span>
            </div>
          )}
          {company.email && (
            <div className="flex items-center gap-2 text-sm">
              <FiMail className="text-primaryBlue shrink-0" />
              <span className="font-medium">{company.email}</span>
            </div>
          )}
          {company.phone && (
            <div className="flex items-center gap-2 text-sm">
              <FiPhone className="text-primaryBlue shrink-0" />
              <span className="font-medium">{company.phone}</span>
            </div>
          )}
          {company.address && (
            <div className="flex items-center gap-2 text-sm sm:col-span-2">
              <FiMapPin className="text-primaryBlue shrink-0" />
              <span className="font-medium">{company.address}</span>
            </div>
          )}
          {company.industry && (
            <div className="flex items-center gap-2 text-sm">
              <FiGrid className="text-primaryBlue shrink-0" />
              <span className="text-gray-500">Industry:</span>
              <span className="font-medium">{company.industry}</span>
            </div>
          )}
        </div>
      </div>

      {/* Documents */}
      <DocumentTable
        title="Company Documents"
        documents={documents}
        onAdd={() => setShowDocModal(true)}
        onRefresh={load}
      />

      {/* Active Employees */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-base font-semibold text-primaryBlue">
            Employees ({filteredEmployees.length}{empSearch && ` of ${employees.length}`})
          </h2>
          <button
            onClick={() => setShowEmpModal(true)}
            className="flex items-center gap-2 bg-primaryBlue text-white px-4 py-2 rounded-lg hover:bg-blue-900 transition text-sm"
          >
            <FiPlus size={14} /> Add Employee
          </button>
        </div>

        {/* Employee Search */}
        <div className="relative mb-4">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
          <input
            value={empSearch}
            onChange={(e) => setEmpSearch(e.target.value)}
            placeholder="Search by name, department, designation, code..."
            className="w-full pl-9 pr-4 py-2 text-sm border rounded-lg bg-gray-50 dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue"
          />
          {empSearch && (
            <button
              onClick={() => setEmpSearch("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-xs"
            >
              ✕
            </button>
          )}
        </div>

        {filteredEmployees.length === 0 ? (
          <p className="text-gray-400 text-sm text-center py-8">
            {empSearch ? `No employees matching "${empSearch}"` : "No active employees."}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>{tableHeaders}</thead>
              <tbody>
                {filteredEmployees.map((emp) => <EmployeeRow key={emp.id} emp={emp} isFormer={false} />)}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Former Employees */}
      {formerEmployees.length > 0 && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow overflow-hidden">
          <button
            onClick={() => setShowFormer(!showFormer)}
            className="w-full flex justify-between items-center p-6 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition"
          >
            <div className="flex items-center gap-2">
              <h2 className="text-base font-semibold text-gray-400">Former Employees</h2>
              <span className="text-xs bg-red-100 text-red-500 dark:bg-red-900/30 dark:text-red-400 px-2 py-0.5 rounded-full">
                {formerEmployees.length}
              </span>
            </div>
            {showFormer ? <FiChevronUp className="text-gray-400" /> : <FiChevronDown className="text-gray-400" />}
          </button>

          {showFormer && (
            <div className="px-6 pb-6">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>{tableHeaders}</thead>
                  <tbody>
                    {formerEmployees.map((emp) => <EmployeeRow key={emp.id} emp={emp} isFormer={true} />)}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      <AnimatePresence>
        {showDocModal && (
          <AddDocumentModal
            entityType="company"
            entityId={id}
            onClose={() => setShowDocModal(false)}
            onSuccess={() => { load(); setShowDocModal(false); }}
          />
        )}
        {showEmpModal && (
          <AddEmployeeModal
            companyId={Number(id)}
            onClose={() => setShowEmpModal(false)}
            onSuccess={() => { load(); setShowEmpModal(false); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
