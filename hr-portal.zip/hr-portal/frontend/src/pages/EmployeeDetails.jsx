import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { getEmployeeById, updateEmployee } from "../services/EmployeeService";
import { getDocuments } from "../services/documentService";
import { getCompanyById } from "../services/companyService";
import AddDocumentModal from "../components/modals/AddDocumentModal";
import DocumentTable from "../components/tables/DocumentTable";
import {
  FiArrowLeft, FiMail, FiPhone, FiCalendar,
  FiBriefcase, FiDollarSign, FiUser, FiEdit2, FiCheck, FiX
} from "react-icons/fi";

const UPLOAD_BASE = import.meta.env.VITE_API_URL
  ? import.meta.env.VITE_API_URL.replace("/api/v1", "")
  : "http://localhost:8001";

export default function EmployeeDetails() {
  const { id, empId } = useParams();
  const navigate = useNavigate();

  const [employee, setEmployee] = useState(null);
  const [company, setCompany] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDocModal, setShowDocModal] = useState(false);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [emp, docs] = await Promise.all([
        getEmployeeById(empId),
        getDocuments("employee", empId),
      ]);
      setEmployee(emp);
      setForm({
        name: emp.name || "",
        email: emp.email || "",
        phone: emp.phone || "",
        designation: emp.designation || "",
        department: emp.department || "",
        salary: emp.salary || "",
        status: emp.status || "Active",
        joinedAt: emp.joined_at ? emp.joined_at.split("T")[0] : "",
        companyEmployeeCode: emp.company_employee_code || "",
      });
      setDocuments(docs || []);
      if (id) {
        const c = await getCompanyById(id);
        setCompany(c);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [empId]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateEmployee(empId, form);
      setEditing(false);
      load();
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return (
    <div className="space-y-4 animate-pulse p-6">
      <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-64" />
      <div className="h-48 bg-gray-200 dark:bg-gray-700 rounded-xl" />
    </div>
  );

  if (!employee) return <div className="p-6 text-red-500">Employee not found.</div>;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 flex-wrap">
        <button onClick={() => navigate(-1)} className="text-gray-400 hover:text-primaryBlue transition">
          <FiArrowLeft size={20} />
        </button>
        <div className="flex items-center gap-3 flex-1 min-w-0">
          {employee.photo_path ? (
            <img
              src={`${UPLOAD_BASE}/${employee.photo_path}`}
              className="w-12 h-12 rounded-full object-cover border-2 border-primaryBlue/30"
              alt={employee.name}
            />
          ) : (
            <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center text-primaryBlue font-bold text-xl">
              {employee.name?.charAt(0).toUpperCase()}
            </div>
          )}
          <div className="min-w-0">
            <h1 className="text-xl font-bold text-primaryBlue truncate">{employee.name}</h1>
            <p className="text-sm text-gray-500">
              {employee.designation || "—"}
              {company && <span className="ml-2">· {company.name}</span>}
            </p>
          </div>
        </div>
        <span className={`text-xs px-3 py-1 rounded-full font-medium ${
          employee.status === "Active"
            ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
            : "bg-gray-100 text-gray-500"
        }`}>{employee.status}</span>
        {!editing ? (
          <button
            onClick={() => setEditing(true)}
            className="flex items-center gap-1 text-sm border border-gray-200 dark:border-gray-600 px-3 py-1.5 rounded-lg hover:border-primaryBlue hover:text-primaryBlue transition"
          >
            <FiEdit2 size={13} /> Edit
          </button>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-1 text-sm bg-primaryBlue text-white px-3 py-1.5 rounded-lg hover:bg-blue-900 transition"
            >
              <FiCheck size={13} /> {saving ? "Saving…" : "Save"}
            </button>
            <button
              onClick={() => setEditing(false)}
              className="flex items-center gap-1 text-sm border px-3 py-1.5 rounded-lg text-gray-500 hover:text-red-500 transition"
            >
              <FiX size={13} /> Cancel
            </button>
          </div>
        )}
      </div>

      {/* Employee Info */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow">
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-5">Personal & Job Info</h2>
        {editing ? (
          <div className="grid sm:grid-cols-2 gap-4">
            {[
              ["name", "Full Name", "text"],
              ["email", "Email", "email"],
              ["phone", "Phone", "tel"],
              ["designation", "Designation", "text"],
              ["department", "Department", "text"],
              ["salary", "Salary", "number"],
              ["joinedAt", "Joining Date", "date"],
              ["companyEmployeeCode", "Company Employee Code", "text"],
            ].map(([field, label, type]) => (
              <div key={field}>
                <label className="block text-xs text-gray-400 mb-1">{label}</label>
                <input
                  type={type}
                  value={form[field] || ""}
                  onChange={e => setForm({ ...form, [field]: e.target.value })}
                  className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue"
                />
              </div>
            ))}
            <div>
              <label className="block text-xs text-gray-400 mb-1">Status</label>
              <select
                value={form.status}
                onChange={e => setForm({ ...form, status: e.target.value })}
                className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue"
              >
                <option>Active</option>
                <option>Inactive</option>
                <option>On Leave</option>
              </select>
            </div>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {/* System ID */}
            <div className="flex items-center gap-3 text-sm sm:col-span-2">
              <div className="flex items-center gap-2 bg-gray-50 dark:bg-gray-700 px-3 py-2 rounded-lg">
                <span className="text-gray-400 text-xs">Portal ID</span>
                <span className="font-mono font-bold text-primaryBlue">#{employee.id}</span>
              </div>
              {employee.company_employee_code && (
                <div className="flex items-center gap-2 bg-blue-50 dark:bg-blue-900/20 px-3 py-2 rounded-lg">
                  <span className="text-gray-400 text-xs">Company Code</span>
                  <span className="font-mono font-bold text-primaryBlue">{employee.company_employee_code}</span>
                </div>
              )}
              <div className="flex items-center gap-2 bg-gray-50 dark:bg-gray-700 px-3 py-2 rounded-lg">
                <span className="text-gray-400 text-xs">System Code</span>
                <span className="font-mono text-xs text-gray-500">{employee.employee_code}</span>
              </div>
            </div>
            {[
              [FiMail, "Email", employee.email],
              [FiPhone, "Phone", employee.phone],
              [FiBriefcase, "Designation", employee.designation],
              [FiUser, "Department", employee.department],
              [FiDollarSign, "Salary", employee.salary ? `₹ ${Number(employee.salary).toLocaleString()}` : null],
              [FiCalendar, "Joined", employee.joined_at ? new Date(employee.joined_at).toLocaleDateString() : null],
            ].map(([Icon, label, value]) => value ? (
              <div key={label} className="flex items-center gap-3 text-sm">
                <Icon className="text-primaryBlue shrink-0" size={15} />
                <span className="text-gray-500 w-28 shrink-0">{label}</span>
                <span className="font-medium">{value}</span>
              </div>
            ) : null)}
          </div>
        )}
      </div>

      {/* Documents */}
      <DocumentTable
        title="Employee Documents"
        documents={documents}
        onAdd={() => setShowDocModal(true)}
        onRefresh={load}
      />

      <AnimatePresence>
        {showDocModal && (
          <AddDocumentModal
            entityType="employee"
            entityId={empId}
            onClose={() => setShowDocModal(false)}
            onSuccess={() => { load(); setShowDocModal(false); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
