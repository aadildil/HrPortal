import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { searchCompanies } from "../services/companyService";
import { searchEmployeesByCompanyId } from "../services/EmployeeService";
import { api } from "../api/httpClient";
import {
  FiDownload, FiFilter, FiUsers, FiFileText, FiChevronDown, FiChevronUp
} from "react-icons/fi";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8001/api/v1";

const downloadCSV = async (url) => {
  const token = localStorage.getItem("sw_token");
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  const text = await res.text();
  const blob = new Blob([text], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = url.includes("employee") ? "employee-report.csv" : "company-report.csv";
  a.click();
};

const buildQuery = (params) =>
  Object.entries(params)
    .filter(([, v]) => v)
    .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
    .join("&");

export default function Reports() {
  const [tab, setTab] = useState("company");
  const [companies, setCompanies] = useState([]);
  const [employees, setEmployees] = useState([]);

  // Company report filters
  const [companyFilters, setCompanyFilters] = useState({
    companyId: "", status: "", fromDate: "", toDate: ""
  });

  // Employee report filters
  const [empFilters, setEmpFilters] = useState({
    companyId: "", employeeId: "", department: "", status: ""
  });

  const [companyData, setCompanyData] = useState(null);
  const [empData, setEmpData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showEmpDocs, setShowEmpDocs] = useState(false);
  const [showCompanyDocs, setShowCompanyDocs] = useState(false);

  useEffect(() => {
    searchCompanies({ pageSize: 100 }).then(d => setCompanies(d.content || []));
  }, []);

  useEffect(() => {
    if (empFilters.companyId) {
      searchEmployeesByCompanyId({ companyId: Number(empFilters.companyId), pageSize: 200 })
        .then(d => setEmployees(d.content || []));
    } else {
      setEmployees([]);
      setEmpFilters(f => ({ ...f, employeeId: "" }));
    }
  }, [empFilters.companyId]);

  const fetchCompanyReport = async () => {
    setLoading(true);
    try {
      const data = await api.get(`/reports/company?${buildQuery(companyFilters)}`);
      setCompanyData(data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const fetchEmpReport = async () => {
    setLoading(true);
    try {
      const data = await api.get(`/reports/employee?${buildQuery(empFilters)}`);
      setEmpData(data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const inputCls = "border rounded-lg px-3 py-2 text-sm dark:bg-gray-700 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primaryBlue w-full";
  const labelCls = "block text-xs text-gray-400 mb-1";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primaryBlue">Reports</h1>
        <p className="text-sm text-gray-500 mt-1">Filter and download company or employee reports</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-gray-200 dark:border-gray-700">
        {[["company", "Company Report", FiUsers], ["employee", "Employee Report", FiFileText]].map(([key, label, Icon]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 transition -mb-px ${
              tab === key
                ? "border-primaryBlue text-primaryBlue"
                : "border-transparent text-gray-400 hover:text-gray-600"
            }`}
          >
            <Icon size={15} /> {label}
          </button>
        ))}
      </div>

      {/* ── COMPANY REPORT ── */}
      {tab === "company" && (
        <div className="space-y-5">
          {/* Filters */}
          <div className="bg-white dark:bg-gray-800 p-5 rounded-xl shadow">
            <div className="flex items-center gap-2 mb-4 text-sm font-medium text-gray-600 dark:text-gray-300">
              <FiFilter size={14} /> Filters
            </div>
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className={labelCls}>Company</label>
                <select className={inputCls} value={companyFilters.companyId}
                  onChange={e => setCompanyFilters({ ...companyFilters, companyId: e.target.value })}>
                  <option value="">All Companies</option>
                  {companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className={labelCls}>Status</label>
                <select className={inputCls} value={companyFilters.status}
                  onChange={e => setCompanyFilters({ ...companyFilters, status: e.target.value })}>
                  <option value="">All Status</option>
                  <option>Active</option>
                  <option>Inactive</option>
                  <option>On Leave</option>
                </select>
              </div>
              <div>
                <label className={labelCls}>Joined From</label>
                <input type="date" className={inputCls} value={companyFilters.fromDate}
                  onChange={e => setCompanyFilters({ ...companyFilters, fromDate: e.target.value })} />
              </div>
              <div>
                <label className={labelCls}>Joined To</label>
                <input type="date" className={inputCls} value={companyFilters.toDate}
                  onChange={e => setCompanyFilters({ ...companyFilters, toDate: e.target.value })} />
              </div>
            </div>
            <div className="flex justify-end mt-4">
              <button onClick={fetchCompanyReport} disabled={loading}
                className="flex items-center gap-2 bg-primaryBlue text-white px-5 py-2 rounded-lg text-sm hover:bg-blue-900 transition disabled:opacity-60">
                {loading ? "Loading..." : "Generate Report"}
              </button>
            </div>
          </div>

          {/* Results */}
          {companyData && (
            <div className="space-y-4">
              {/* Employees Table */}
              <div className="bg-white dark:bg-gray-800 p-5 rounded-xl shadow">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-base font-semibold text-primaryBlue">
                    Employees ({companyData.employees.length})
                  </h2>
                  <button
                    onClick={() => downloadCSV(`${API_BASE}/reports/company-csv?${buildQuery({ ...companyFilters, type: "employees" })}`)}
                    className="flex items-center gap-2 border border-primaryBlue text-primaryBlue px-3 py-1.5 rounded-lg text-sm hover:bg-blue-50 dark:hover:bg-blue-900/20 transition"
                  >
                    <FiDownload size={13} /> Download CSV
                  </button>
                </div>
                {companyData.employees.length === 0 ? (
                  <p className="text-gray-400 text-sm text-center py-6">No employees found</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-100 dark:border-gray-700 text-xs uppercase tracking-wider text-gray-400">
                          {["Name", "Company", "Code", "Designation", "Department", "Email", "Phone", "Salary", "Status", "Joined"].map(h => (
                            <th key={h} className="pb-3 text-left font-medium pr-4">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {companyData.employees.map((emp, i) => (
                          <motion.tr key={emp.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.02 }}
                            className="border-b border-gray-50 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                            <td className="py-2 pr-4 font-medium text-primaryBlue">{emp.name}</td>
                            <td className="py-2 pr-4 text-gray-500">{emp.company_name}</td>
                            <td className="py-2 pr-4 font-mono text-xs text-gray-400">{emp.company_employee_code || emp.employee_code}</td>
                            <td className="py-2 pr-4">{emp.designation || "—"}</td>
                            <td className="py-2 pr-4">{emp.department || "—"}</td>
                            <td className="py-2 pr-4 text-gray-500">{emp.email || "—"}</td>
                            <td className="py-2 pr-4 text-gray-500">{emp.phone || "—"}</td>
                            <td className="py-2 pr-4">{emp.salary ? `₹${Number(emp.salary).toLocaleString()}` : "—"}</td>
                            <td className="py-2 pr-4">
                              <span className={`text-xs px-2 py-0.5 rounded-full ${
                                emp.status === "Active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"
                              }`}>{emp.status}</span>
                            </td>
                            <td className="py-2 pr-4 text-gray-500 text-xs">
                              {emp.joined_at ? new Date(emp.joined_at).toLocaleDateString() : "—"}
                            </td>
                          </motion.tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Company Documents */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow overflow-hidden">
                <button onClick={() => setShowCompanyDocs(!showCompanyDocs)}
                  className="w-full flex justify-between items-center p-5 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition">
                  <div className="flex items-center gap-3">
                    <h2 className="text-base font-semibold text-primaryBlue">
                      Company Documents ({companyData.documents.length})
                    </h2>
                    {companyData.documents.length > 0 && (
                      <button
                        onClick={(e) => { e.stopPropagation(); downloadCSV(`${API_BASE}/reports/company-csv?${buildQuery({ ...companyFilters, type: "documents" })}`); }}
                        className="flex items-center gap-1 border border-primaryBlue text-primaryBlue px-3 py-1 rounded-lg text-xs hover:bg-blue-50 dark:hover:bg-blue-900/20 transition"
                      >
                        <FiDownload size={11} /> CSV
                      </button>
                    )}
                  </div>
                  {showCompanyDocs ? <FiChevronUp className="text-gray-400" /> : <FiChevronDown className="text-gray-400" />}
                </button>
                {showCompanyDocs && (
                  <div className="px-5 pb-5 overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-100 dark:border-gray-700 text-xs uppercase tracking-wider text-gray-400">
                          {["Document Name", "Company", "Type", "Expiry Date", "Uploaded On"].map(h => (
                            <th key={h} className="pb-3 text-left font-medium pr-4">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {companyData.documents.map((doc, i) => (
                          <tr key={doc.id} className="border-b border-gray-50 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                            <td className="py-2 pr-4 font-medium">{doc.document_name}</td>
                            <td className="py-2 pr-4 text-gray-500">{doc.company_name}</td>
                            <td className="py-2 pr-4">
                              <span className="text-xs bg-blue-50 dark:bg-blue-900/30 text-primaryBlue px-2 py-0.5 rounded-full">{doc.document_type || "—"}</span>
                            </td>
                            <td className="py-2 pr-4 text-gray-500 text-xs">
                              {doc.expiry_date ? new Date(doc.expiry_date).toLocaleDateString() : "—"}
                            </td>
                            <td className="py-2 pr-4 text-gray-400 text-xs">
                              {new Date(doc.uploaded_at).toLocaleDateString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── EMPLOYEE REPORT ── */}
      {tab === "employee" && (
        <div className="space-y-5">
          <div className="bg-white dark:bg-gray-800 p-5 rounded-xl shadow">
            <div className="flex items-center gap-2 mb-4 text-sm font-medium text-gray-600 dark:text-gray-300">
              <FiFilter size={14} /> Filters
            </div>
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className={labelCls}>Company</label>
                <select className={inputCls} value={empFilters.companyId}
                  onChange={e => setEmpFilters({ ...empFilters, companyId: e.target.value, employeeId: "" })}>
                  <option value="">All Companies</option>
                  {companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className={labelCls}>Employee</label>
                <select className={inputCls} value={empFilters.employeeId}
                  onChange={e => setEmpFilters({ ...empFilters, employeeId: e.target.value })}
                  disabled={!empFilters.companyId}>
                  <option value="">All Employees</option>
                  {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                </select>
              </div>
              <div>
                <label className={labelCls}>Department</label>
                <input className={inputCls} placeholder="e.g. Engineering" value={empFilters.department}
                  onChange={e => setEmpFilters({ ...empFilters, department: e.target.value })} />
              </div>
              <div>
                <label className={labelCls}>Status</label>
                <select className={inputCls} value={empFilters.status}
                  onChange={e => setEmpFilters({ ...empFilters, status: e.target.value })}>
                  <option value="">All Status</option>
                  <option>Active</option>
                  <option>Inactive</option>
                  <option>On Leave</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end mt-4">
              <button onClick={fetchEmpReport} disabled={loading}
                className="flex items-center gap-2 bg-primaryBlue text-white px-5 py-2 rounded-lg text-sm hover:bg-blue-900 transition disabled:opacity-60">
                {loading ? "Loading..." : "Generate Report"}
              </button>
            </div>
          </div>

          {empData && (
            <div className="space-y-4">
              {/* Employees */}
              <div className="bg-white dark:bg-gray-800 p-5 rounded-xl shadow">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-base font-semibold text-primaryBlue">
                    Employees ({empData.employees.length})
                  </h2>
                  <button
                    onClick={() => downloadCSV(`${API_BASE}/reports/employee-csv?${buildQuery({ ...empFilters, type: "employees" })}`)}
                    className="flex items-center gap-2 border border-primaryBlue text-primaryBlue px-3 py-1.5 rounded-lg text-sm hover:bg-blue-50 dark:hover:bg-blue-900/20 transition"
                  >
                    <FiDownload size={13} /> Download CSV
                  </button>
                </div>
                {empData.employees.length === 0 ? (
                  <p className="text-gray-400 text-sm text-center py-6">No employees found</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-100 dark:border-gray-700 text-xs uppercase tracking-wider text-gray-400">
                          {["Name", "Company", "Code", "Designation", "Department", "Email", "Phone", "Salary", "Status", "Joined"].map(h => (
                            <th key={h} className="pb-3 text-left font-medium pr-4">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {empData.employees.map((emp, i) => (
                          <motion.tr key={emp.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.02 }}
                            className="border-b border-gray-50 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                            <td className="py-2 pr-4 font-medium text-primaryBlue">{emp.name}</td>
                            <td className="py-2 pr-4 text-gray-500">{emp.company_name}</td>
                            <td className="py-2 pr-4 font-mono text-xs text-gray-400">{emp.company_employee_code || emp.employee_code}</td>
                            <td className="py-2 pr-4">{emp.designation || "—"}</td>
                            <td className="py-2 pr-4">{emp.department || "—"}</td>
                            <td className="py-2 pr-4 text-gray-500">{emp.email || "—"}</td>
                            <td className="py-2 pr-4 text-gray-500">{emp.phone || "—"}</td>
                            <td className="py-2 pr-4">{emp.salary ? `₹${Number(emp.salary).toLocaleString()}` : "—"}</td>
                            <td className="py-2 pr-4">
                              <span className={`text-xs px-2 py-0.5 rounded-full ${
                                emp.status === "Active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"
                              }`}>{emp.status}</span>
                            </td>
                            <td className="py-2 pr-4 text-gray-500 text-xs">
                              {emp.joined_at ? new Date(emp.joined_at).toLocaleDateString() : "—"}
                            </td>
                          </motion.tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Employee Documents */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow overflow-hidden">
                <button onClick={() => setShowEmpDocs(!showEmpDocs)}
                  className="w-full flex justify-between items-center p-5 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition">
                  <div className="flex items-center gap-3">
                    <h2 className="text-base font-semibold text-primaryBlue">
                      Employee Documents ({empData.documents.length})
                    </h2>
                    {empData.documents.length > 0 && (
                      <button
                        onClick={(e) => { e.stopPropagation(); downloadCSV(`${API_BASE}/reports/employee-csv?${buildQuery({ ...empFilters, type: "documents" })}`); }}
                        className="flex items-center gap-1 border border-primaryBlue text-primaryBlue px-3 py-1 rounded-lg text-xs hover:bg-blue-50 dark:hover:bg-blue-900/20 transition"
                      >
                        <FiDownload size={11} /> CSV
                      </button>
                    )}
                  </div>
                  {showEmpDocs ? <FiChevronUp className="text-gray-400" /> : <FiChevronDown className="text-gray-400" />}
                </button>
                {showEmpDocs && (
                  <div className="px-5 pb-5 overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-100 dark:border-gray-700 text-xs uppercase tracking-wider text-gray-400">
                          {["Document Name", "Employee", "Company", "Type", "Expiry Date", "Uploaded On"].map(h => (
                            <th key={h} className="pb-3 text-left font-medium pr-4">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {empData.documents.map((doc) => (
                          <tr key={doc.id} className="border-b border-gray-50 dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                            <td className="py-2 pr-4 font-medium">{doc.document_name}</td>
                            <td className="py-2 pr-4 text-gray-500">{doc.employee_name}</td>
                            <td className="py-2 pr-4 text-gray-500">{doc.company_name}</td>
                            <td className="py-2 pr-4">
                              <span className="text-xs bg-blue-50 dark:bg-blue-900/30 text-primaryBlue px-2 py-0.5 rounded-full">{doc.document_type || "—"}</span>
                            </td>
                            <td className="py-2 pr-4 text-gray-500 text-xs">
                              {doc.expiry_date ? new Date(doc.expiry_date).toLocaleDateString() : "—"}
                            </td>
                            <td className="py-2 pr-4 text-gray-400 text-xs">
                              {new Date(doc.uploaded_at).toLocaleDateString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
