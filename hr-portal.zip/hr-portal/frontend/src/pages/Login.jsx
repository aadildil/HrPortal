import { useState } from "react";
import { motion } from "framer-motion";
import { login } from "../services/authService";
import { FiLock, FiUser, FiEye, FiEyeOff } from "react-icons/fi";

export default function Login({ onLogin }) {
  const [form, setForm] = useState({ username: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const data = await login(form.username, form.password);
      localStorage.setItem("sw_token", data.token);
      localStorage.setItem("sw_user", data.username);
      onLogin(data.username);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4"
      style={{ background: "linear-gradient(135deg, #0f1f5c 0%, #1E3A8A 50%, #1a56c4 100%)" }}
    >
      {/* Background rings */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="absolute rounded-full border border-white/5"
            style={{
              width: `${i * 300}px`,
              height: `${i * 300}px`,
              top: "50%", left: "50%",
              transform: "translate(-50%, -50%)",
            }}
          />
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative w-full max-w-sm"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-4 relative flex items-center justify-center">
            <svg viewBox="0 0 80 80" className="w-16 h-16 absolute">
              <path
                d="M40 4 L72 18 L72 42 C72 58 56 70 40 76 C24 70 8 58 8 42 L8 18 Z"
                fill="rgba(255,255,255,0.1)"
                stroke="rgba(255,255,255,0.8)"
                strokeWidth="1.5"
              />
            </svg>
            <span className="relative z-10 text-white font-bold text-2xl" style={{ fontFamily: "Georgia, serif" }}>S</span>
          </div>
          <h1 className="text-3xl font-bold text-white tracking-widest" style={{ fontFamily: "Georgia, serif" }}>
            SAFEWAY
          </h1>
          <div className="w-24 h-px bg-white/30 mx-auto my-2" />
          <p className="text-blue-200 text-xs tracking-[0.3em] uppercase">Vault</p>
        </div>

        {/* Login card */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl p-8">
          <h2 className="text-lg font-semibold text-gray-800 dark:text-white mb-1">Welcome back</h2>
          <p className="text-sm text-gray-400 mb-6">Sign in to access your portal</p>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-red-50 dark:bg-red-900/20 text-red-500 text-sm px-4 py-2 rounded-lg mb-4 border border-red-100 dark:border-red-800"
            >
              {error}
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs text-gray-400 mb-1.5">Username</label>
              <div className="relative">
                <FiUser className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={15} />
                <input
                  type="text"
                  value={form.username}
                  onChange={e => setForm({ ...form, username: e.target.value })}
                  required
                  placeholder="Enter username"
                  className="w-full pl-9 pr-4 py-2.5 border rounded-lg text-sm dark:bg-gray-800 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1.5">Password</label>
              <div className="relative">
                <FiLock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={15} />
                <input
                  type={showPassword ? "text" : "password"}
                  value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  required
                  placeholder="Enter password"
                  className="w-full pl-9 pr-10 py-2.5 border rounded-lg text-sm dark:bg-gray-800 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <FiEyeOff size={15} /> : <FiEye size={15} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-lg text-sm font-semibold text-white transition disabled:opacity-60 mt-2"
              style={{ background: "linear-gradient(135deg, #1E3A8A, #1a56c4)" }}
            >
              {loading ? "Signing in…" : "Sign In"}
            </button>
          </form>
        </div>

        <p className="text-center text-white/30 text-xs mt-6">
          Safeway Vault · Secure · Store · Safeguard
        </p>
      </motion.div>
    </div>
  );
}
