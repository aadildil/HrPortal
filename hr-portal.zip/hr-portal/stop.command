#!/bin/bash
cd "$(dirname "$0")"
echo ""
echo " Stopping HR Portal..."
docker compose down
echo " HR Portal stopped. Your data is saved."
echo ""
