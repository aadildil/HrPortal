# HR Portal

## How to Run

### Windows
1. Install Docker Desktop (only once)
2. Double-click **start.bat** to launch the app
3. Browser opens automatically at http://localhost:3000
4. Double-click **stop.bat** to stop when done

### Mac
1. Install Docker Desktop (only once)
2. Double-click **start.command** to launch the app
3. Browser opens automatically at http://localhost:3000
4. Double-click **stop.command** to stop when done

> First launch takes 2-3 minutes to download and build. Every launch after that is much faster.

## Your data is always saved
Stopping the app does NOT delete your data. It is stored permanently on your machine.

## Manual commands (optional)
```
docker compose up -d --build   # start
docker compose down            # stop
```
