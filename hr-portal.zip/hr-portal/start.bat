@echo off
title Safeway HR Portal
echo.
echo  ================================
echo      Safeway HR Portal
echo  ================================
echo.

:: Check if LICENSE_KEY is set in .env
findstr /C:"LICENSE_KEY=" .env | findstr /V "LICENSE_KEY=$" | findstr /V "LICENSE_KEY= " > nul 2>&1
if errorlevel 1 (
    echo  WARNING: No LICENSE_KEY found in .env file.
    echo  The app will start but show a license error.
    echo  Contact your vendor to get a license key.
    echo.
)

:: Check if Docker is running
docker info > nul 2>&1
if errorlevel 1 (
    echo  Docker is not running. Opening Docker Desktop...
    start "" "C:\Program Files\Docker\Docker\Docker Desktop.exe"
    echo  Waiting for Docker to start...
    timeout /t 30 /nobreak > nul
)

echo  Starting Safeway HR Portal...
docker compose up -d --build

timeout /t 5 /nobreak > nul

echo  Opening in browser...
start http://localhost:3000

echo.
echo  ================================
echo   Safeway HR Portal is running!
echo   http://localhost:3000
echo  ================================
echo.
pause
