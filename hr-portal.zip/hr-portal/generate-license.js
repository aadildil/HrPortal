/**
 * SAFEWAY HR PORTAL — License Key Generator
 * Run this script to generate a license key for a client machine.
 *
 * Usage:
 *   node generate-license.js <machine-id>
 *
 * Example:
 *   node generate-license.js "aa:bb:cc:dd:ee:ff|11:22:33:44:55:66"
 */

const crypto = require("crypto");

const SECRET = "SAFEWAY_HR_2025_X9K2M"; // Must match backend/src/license/index.js

function generateKey(machineId) {
  const hash = crypto
    .createHmac("sha256", SECRET)
    .update(machineId)
    .digest("hex")
    .toUpperCase()
    .slice(0, 32);
  return hash.match(/.{4}/g).join("-");
}

const machineId = process.argv[2];
if (!machineId) {
  console.log("Usage: node generate-license.js <machine-id>");
  console.log("Get machine ID from: http://localhost:8001/machine-id");
  process.exit(1);
}

const key = generateKey(machineId);
console.log("\n========================================");
console.log("  SAFEWAY HR PORTAL — LICENSE KEY");
console.log("========================================");
console.log("  Machine ID :", machineId);
console.log("  License Key:", key);
console.log("========================================");
console.log("\nAdd this to the client's .env file:");
console.log(`LICENSE_KEY=${key}\n`);
