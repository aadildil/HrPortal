# Safeway Vault — Vendor Guide

## How to set credentials for a client

Before sending the zip to a client, open the `.env` file in the root folder and set:

```
APP_USERNAME=their_username
APP_PASSWORD=their_password
JWT_SECRET=some_random_long_string_only_you_know
```

Each client gets a unique username and password. They use these to log in.

## To revoke access
Simply change APP_USERNAME or APP_PASSWORD in the `.env` file and restart:
```
docker compose down
docker compose up
```

## Important
- Never share the JWT_SECRET
- Give each client a different username/password
- Keep this VENDOR-README.md for yourself — don't include it in the client zip
